# -*- coding: utf-8 -*-
"""
Components used by GUI and by CMD (no GUI).
Keep wx out of the game.
"""

from os.path import isfile, isdir
from math import sqrt
from copy import deepcopy


import zones
import reflections

import dynrockmath as drm

###############################################################################
# I N I T   and   L O A D
###############################################################################
def init_variables(parent):
    """ Initialize variables, lists, etc.
    Keep it updated for better overview.
    """
    # Jana
    parent.JanaLoaded = False
    parent.JanaFiles = []
    parent.JanaPath = None
    parent.JanaJob = None
    
    # Cif_pets
    parent.CifPetsLoaded = False
    parent.CifPetsFile = None
        
    # Objects
    parent.ReflectionBlock = dict()     # ReflectionBlock[1] = ReflectionBlockObject
    parent.ZoneBlock = dict()           # ZoneBlock[1] = ZoneBlockObject

    
def init_jana_job(parent, event=None, file=None):
    """ Define files available for further processing.
    Set Jana folder path from m40 file.
    Set job name
    Check for other usable files: m42 m50 m80 ref
    """
    if file and not (parent.ReflectionBlock or parent.ZoneBlock): # input file provided, check it.
        print(file)
        if isfile(file) and file[-3:] in ("m40", "m42", "m50", "m80", "m83","m90","m95", "ref"): # good candidates
            JanaFile = file
        elif isdir(file):
            JanaFile = parent.file_dialog(directory=file)
        else:
            Path, Job = split_path_job(file)
            if isdir(Path):
                JanaFile = parent.file_dialog(directory=Path)
            else:
                JanaFile = parent.file_dialog()
    else:
        JanaFile = parent.file_dialog()
        
    if JanaFile:
        parent.JanaFiles = get_jana_job_files(JanaFile) # returns a dictionary with "path", "job", "m40", "m42" etc
        parent.JanaPath = parent.JanaFiles["path"]
        parent.JanaJob = parent.JanaFiles["job"]
        parent.JanaLoaded = True
        parent.log(entry="\n"+parent.JanaPath)
        parent.log(entry="Loading Jana job: >>> "+parent.JanaJob)
        parent.SetTitle(parent.JanaJob+" >>> in  ..."+"{:40.40}".format(parent.JanaPath[::-1])[::-1])
        print(parent.JanaJob)
        
        # Import blocks.
        ZoneBlocks = zones.m42_import(parent)
        ReflectionBlocks = reflections.ref_import(parent) # try ref file, it reflections were not loaded, import via m83 file
        From = "REF"
        if not ReflectionBlocks:
            print("Read M83")
            ReflectionBlocks = reflections.m83_import(parent)
            From = "M83"
            
        for BlockID in ZoneBlocks.keys():
            FromMsg = From
            if BlockID not in ReflectionBlocks.keys():
                ReflectionBlocks[BlockID] = None
                FromMsg = "---"
            NewBlockID = implement_block(parent, ZoneBlocks[BlockID], ReflectionBlocks[BlockID])
            parent.log(entry="BlockID "+str(BlockID)+" imported as BlockID "+str(NewBlockID)+" from M42/"+FromMsg+".")
        parent.status()
        return True
    else:
        parent.log("Jana files could not be loaded.")
        return False
    
def merge_sym_reflections(parent, event=None):
    " Only for BlockID 1, create BlockID 2"
    NewBlockID = copy_block(parent, event=None, readblockID=1, newblockID=11)
    Block = parent.ReflectionBlock[NewBlockID]
    Block.dI_sym = list()
    Block.dazimuth = list()
    Counter = 0
    for i, HKL in enumerate(Block.HKL):
        symHKL = (-HKL[0], HKL[1], -HKL[2])
        if HKL != symHKL and symHKL in Block.HKL: #[i:]
            isym = Block.HKL.index(symHKL)
            Im = (Block.Io[i] - Block.Io[isym])/2 #(Block.Io[i] + Block.Io[isym])/2
            print(f"{i:4} {Im:7.2f} from merging {Block.Io[i]:7.2f} and {Block.Io[isym]:7.2f}. Azimuth1,2 {Block.azimuth[i]:5.2f}, {Block.azimuth[isym]:5.2f} ", HKL, symHKL)
            Block.dI_sym.append(Im)
            Block.dazimuth.append(Block.azimuth[i]-Block.azimuth[isym])
            Counter +=1
        else:
            Block.dI_sym.append(float("NaN"))
            Block.dazimuth.append(float("NaN"))
    print(Counter, " reflections merged from h,k,l and -h,k,-l.")
    
def init_cif_pets_job(parent, event=None, file=None):
    if not (parent.ReflectionBlock or parent.ZoneBlock):
        if file and file.endswith("cif_pets"):
            CifPetsFile = file
        elif parent.CifPetsFile:
            CifPetsFile = parent.CifPetsFile
        else:
            CifPetsFile = parent.file_dialog(extension="cif_pets")
    else:
        CifPetsFile = parent.file_dialog(extension="cif_pets")
    if not CifPetsFile:
        return False
    print(CifPetsFile)
    Path, Job = split_path_job(CifPetsFile)
    parent.SetTitle(Job+".cif_pets >>> ..."+"{:40.40}".format(Path[::-1])[::-1])
    parent.CifPetsFile = CifPetsFile
    
    NewZoneBlock = zones.cif_pets_import_zones(parent, CifPetsFile)
    NewReflectionBlock = reflections.cif_pets_import_reflections(parent, CifPetsFile)
    if NewZoneBlock[1].Geometry:
        NewReflectionBlock[1].Geometry = NewZoneBlock[1].Geometry
    implement_block(parent, zoneblock=NewZoneBlock[1], reflectionblock=NewReflectionBlock[1])
    parent.status()
    parent.log(entry="Data imported from CIF_PETS")
    #parent.log(entry="MERGing...")
    #merge_sym_reflections(parent)
    return True
    
def init_reflprofiles_job(parent, event=None, file=None):
    if file and (file.endswith("rprofall") or file.endswith("rprofstr") or file.endswith("reflprofiles_all.dat") or file.endswith("reflprofiles_strong.dat")):
        CifPetsFile = file
    else:
        CifPetsFile = parent.file_dialog(extension="rprofall")
    if not CifPetsFile:
        return False
    print(CifPetsFile)
    Path, Job = split_path_job(CifPetsFile)
    parent.SetTitle(Job+" refl >>> ..."+"{:40.40}".format(Path[::-1])[::-1])
    parent.CifPetsFile = CifPetsFile
    
    NewReflectionBlock = reflections.rprof_import_reflections(parent, CifPetsFile)
    implement_block(parent, zoneblock=None, reflectionblock=NewReflectionBlock[1])
    parent.status()
    parent.log(entry="Data imported from "+CifPetsFile)    
    return True
    
def init_dyntmp_job(parent, event=None, file=None):  
    if file and file.endswith("dyntmp"):
        DyntmpFile = file
    else:
        DyntmpFile = parent.file_dialog(extension="dyntmp")
    if not DyntmpFile:
        return False
    print(DyntmpFile)
    Path, Job = split_path_job(DyntmpFile)
    parent.SetTitle(f"{Job} dyntmp >>> ... {Path[::-1][::-1]:40.40}")
    parent.DyntmpFile = DyntmpFile
    
    NewReflectionBlock = reflections.dyntmp_import_reflections(parent, DyntmpFile)
    implement_block(parent, zoneblock=None, reflectionblock=NewReflectionBlock[1])
    implement_block(parent, zoneblock=None, reflectionblock=NewReflectionBlock[2])
    parent.status()
    parent.log(entry="Data imported from "+DyntmpFile)    
    return True

def init_ptsopt_job(parent, event=None, file=None):
    if file and file.endswith("ptsopt"):
        PtsOptFile = file
    elif parent.CifPetsFile:
        PtsOptFile = parent.CifPetsFile
    else:
        PtsOptFile = parent.file_dialog(extension="ptsopt")
    print("Reading ", PtsOptFile, end="")
    NewZoneBlock = zones.ptsopt_import_zones(parent, file=PtsOptFile)
    print(" ... OK.")
    NewBlockID = implement_block(parent, NewZoneBlock[1], None)
    parent.ZoneBlock[NewBlockID].smooth_steps()
    parent.log(entry="Smooth orientation.")
    parent.status()
    return True
    
    
def load_m80_file(parent, event=None, file=None):
    if file and file.endswith("m80") and isfile(file):
        M80File = file
        parent.JanaPath, parent.JanaJob = split_path_job(M80File)
    elif "m80" in parent.JanaFiles:
        M80File = parent.JanaFiles["m80"]
    print(M80File)
    parent.log(entry=M80File)
    Blocks = reflections.m80_import_reflections(parent, M80File)
    for BlockID in Blocks.keys():
        NewBlockID = BlockID+80
        parent.ReflectionBlock[NewBlockID] = Blocks[BlockID]
        parent.ReflectionBlock[NewBlockID].BlockID = NewBlockID
        parent.ReflectionBlock[NewBlockID].convert_IF()
        parent.log(entry="BlockID "+str(NewBlockID)+" imported from M80 BlockID "+str(BlockID)+".")
    parent.status()
    return True

        
###############################################################################
# B L O C K   Management
###############################################################################

def implement_block(parent, zoneblock, reflectionblock):
    ''' Check suggested blockID of new blocks and already present blockID in parent.ZoneBlock/.ReflectionBlock
    Make sure that new ZoneBlockID and new ReflectionBlockID are identical.
    '''
    # Current IDs
    PresentBlockIDs = set(parent.ZoneBlock.keys()) | set(parent.ReflectionBlock.keys())
    PresentSuggestedID = max(PresentBlockIDs)+1 if PresentBlockIDs else 1
    
    # Suggested ID >= PresentSuggestedID
    NewBlockID = PresentSuggestedID
    if type(zoneblock) == "__main__.zoneblock" and zoneblock.BlockID and zoneblock.BlockID >= PresentSuggestedID:
        NewBlockID = zoneblock.BlockID
    if type(reflectionblock) == "__main__.reflectionsblock" and reflectionblock.BlockID and reflectionblock.BlockID >= NewBlockID:
        NewBlockID = reflectionblock.BlockID
    
    # Implement the block
    if zoneblock:
        parent.ZoneBlock[NewBlockID] = zoneblock        
        parent.ZoneBlock[NewBlockID].JanaBlockID = parent.ZoneBlock[NewBlockID].BlockID
        parent.ZoneBlock[NewBlockID].BlockID = NewBlockID
        parent.ZoneBlock[NewBlockID].calc_steps()
    if reflectionblock:
        parent.ReflectionBlock[NewBlockID] = reflectionblock
        parent.ReflectionBlock[NewBlockID].JanaBlockID = parent.ReflectionBlock[NewBlockID].BlockID
        parent.ReflectionBlock[NewBlockID].BlockID = NewBlockID
        parent.ReflectionBlock[NewBlockID].convert_IF()
        parent.ReflectionBlock[NewBlockID].calc_r()
        parent.ReflectionBlock[NewBlockID].m80_fo_fc()
    if zoneblock:
        parent.ZoneBlock[NewBlockID].set_wavelength()
    if reflectionblock:
        parent.ReflectionBlock[NewBlockID].calc_hkl_geometry()
    return NewBlockID    
    

def copy_block(parent, event=None, readblockID=None, newblockID=None):
    """ Create a copy of a block with a new blockID.
    Maybe useful before filtering reflections.
    """
    if readblockID:
        BlockID = readblockID
    else:
        BlockID = block_dialog(parent, request="Enter Block ID of the block that should be copied:", multiple=False)
    if newblockID:
        NewBlockID = newblockID
    else:
        NewBlockID = int( parent.input_dialog(parent, request="Enter new Block ID") )
    # temporarily remove reference to parent, which cannot be copied
    parent.ReflectionBlock[BlockID].Mother = None
    parent.ZoneBlock[BlockID].Mother = None
    # copy
    parent.ReflectionBlock[NewBlockID] = deepcopy(parent.ReflectionBlock[BlockID])
    parent.ReflectionBlock[NewBlockID].BlockID = NewBlockID
    parent.ZoneBlock[NewBlockID] = deepcopy(parent.ZoneBlock[BlockID])
    parent.ZoneBlock[NewBlockID].BlockID = NewBlockID
    # restore reference to parent
    parent.ReflectionBlock[BlockID].Mother = parent
    parent.ZoneBlock[BlockID].Mother = parent
    parent.ReflectionBlock[NewBlockID].Mother = parent
    parent.ZoneBlock[NewBlockID].Mother = parent
    
    parent.log(entry="Created Block "+str(NewBlockID)+" as a copy of Block "+str(BlockID)+".")
    parent.status()
    return NewBlockID

def reset(parent, event=None):
    " Remove selected ZoneBlocks and ReflectionBlocks. Removing all is like restarting DynRock."
    ZIDs = " ".join([ str(i) for i in parent.ZoneBlock  ])
    RIDs = " ".join([ str(i) for i in parent.ReflectionBlock ])
    Message = "Delete ZoneBlock(s) and RefelectionBlock(s)\n"
    Message += "Loaded ZoneBlocks: "+ZIDs
    Message += "\nLoaded ReflectionBlocks: "+RIDs          
    Message += "\nExample: 1\nExample: 1 3\nExample: all"
    
    Answer = parent.input_dialog(request=Message, title="Delete blocks", default="all")
    print("Delete blocks: ", Answer)
    if Answer == "all":
        IDs = [ BlockID for BlockID in parent.ZoneBlock ]
    else:
        IDs = [ int(item) for item in Answer.split() ]
    for BlockID in IDs:
       if BlockID in parent.ZoneBlock:
           del parent.ZoneBlock[BlockID]
       if BlockID in parent.ReflectionBlock:
           del parent.ReflectionBlock[BlockID]
    parent.status()
    return True

def m80_block_manager(parent, event=None):
    " Select blocks that should be used to rewrite the M80 file with a single block. "
    BlockIDs = block_dialog(parent, request="Use which blocks for the new M80 file?", multiple=True)
    Label = "_".join([str(i) for i in BlockIDs])
    M80File = parent.JanaPath+parent.JanaJob+"_DynRock_"+Label+".m80"
    fh = open(M80File, "w")
    fh.write("Block1 begin   DynRock_"+Label+"\n")
    for BlockID in BlockIDs:
        for Line in parent.ReflectionBlock[BlockID].M80Line:
            fh.write(Line)
    fh.write("Block1 end\n")
    fh.close()
    parent.log(entry="Merged M80 blocks. Output file: ..._DynRock_"+Label+".m80")
    return True
        
        
    
    
###############################################################################
# H A N D L E   R E F L E C T I O N S
#input_dialog(self, event=None, request="Enter 3 integers:", default="", title="User input request", parameters=None)
###############################################################################
def geometry_continuous(parent):
    for Block in parent.ZoneBlock.values():
        Block.set_continuous_geometry()
    parent.status_zones()
        
def geometry_precession(parent):
    for Block in parent.ZoneBlock.values():
        Block.set_precession_geometry()        
    parent.status_zones()
    
def update_reflection_geometry(parent, event=None):
    AllDF = list()
    #AllDI = list()
    for BlockID in parent.ReflectionBlock:
        parent.log(entry="Calculating reflection geometry of Block "+str(BlockID))
        parent.ReflectionBlock[BlockID].calc_hkl_geometry()
        parent.ReflectionBlock[BlockID].skip_r()
        parent.ReflectionBlock[BlockID].calc_DF_distribution()
        AllDF += parent.ReflectionBlock[BlockID].wDF
        #AllDI += parent.ReflectionBlock[BlockID].DI_over_sigma
    Mean, Sigma = drm.standard_uncertainty(AllDF)
    Msg = "ALL: Mean wDF: " + "{:8.4f}".format(Mean) + "   Sigma: " + "{:8.4f}".format(Sigma) + "    4*Sigma: " + "{:8.4f}".format(4*Sigma)
    parent.log(entry=Msg)
    print(Msg)
    parent.status_reflections()      
    
def filter_reflections(parent, event=None):
    """ Remove reflections from a block according to flexible filter settings.
    This may be useful to exclude selected reflections from a refinement if the
    corrsponding setting is not possible with 
    This functions calls the method 'filter_reflections' for each selected reflection block.
    """
    Message = """Enter filter triplets (Parameter, Min, Max).
                 Filtered reflections will be deleted from the object.
                 Example 1: DSg 0.002 1
                 Example 2: g 0 1.3   Fo 0 100
                 Example 3: h -3 3   k -3 3   l 0 0"""
    # Which Blocks?
    IDs = block_dialog(parent, request="Filter reflections from which BlockID(s)?", multiple=True)
    # Define filter
    Filter = parent.input_dialog(request=Message, default="DSg 0.0025 1", title="Filter reflections")    
    if len(Filter.split())%3 > 0:
        parent.log(entry="Filter is not valied: "+Filter)
        parent.log(entry="Please input three parameters for each active filter: parameter1 low_limit1 high_limit1 parameter2 low_limit2 high_limit2")
        return False
    Filter = Filter.split()
    Parameters = [ element for (i, element) in enumerate(Filter) if i%3 == 0 and hasattr(parent.ReflectionBlock[1], element)]
    if len(Parameters) != len(Filter)/3:
        parent.log(entry="Filter parameter not found.")
    LowLimit = [ float(element) for (i, element) in enumerate(Filter) if i%3 == 1 ]
    HighLimit = [ float(element) for (i, element) in enumerate(Filter) if i%3 == 2 ]
    # Call filter function of selected blocks
    for BlockID in IDs:
        if LowLimit > HighLimit: # 26.08.2022
            LowLimit, HighLimit = HighLimit, LowLimit
        parent.ReflectionBlock[BlockID].filter_reflections(parameters=Parameters, lowlimit=LowLimit, highlimit=HighLimit)
    parent.status()
    #print("Done.", Filter)

def apply_scales(parent, event=None):
    """ Multiply Io and Ic by scale """
    print("scales")
    BlockIDs = block_dialog(parent, request="Apply scales of which BlockID?", multiple=True)
    for BlockID in BlockIDs:
        zoneblock = parent.ZoneBlock[BlockID]
        reflectionblock = parent.ReflectionBlock[BlockID]
        # Prepare dict ZoneID -> scale
        if not zoneblock.scale: # scales not available
            parent.log(entry="Scale factors not availabe for Block "+str(BlockID))
            continue
        Scales = dict(zip(zoneblock.ZoneID, zoneblock.scale))
        # Loop through all reflections
        for i in range(len(reflectionblock.Io)):
            Scale = Scales[reflectionblock.ZoneID[i]]
            reflectionblock.Io[i] = reflectionblock.Io[i]*Scale
            reflectionblock.Isigma[i] = reflectionblock.Isigma[i]*Scale
        parent.log(entry="Scales applied to Block "+str(BlockID))
    return True
      
###############################################################################
###############################################################################    
def merge_frames(parent):    
    """ Dialogue:
    a) merge M frames, S step size
    b) Dynamic depending on alpha jumps, beta jumps, etc.
    Until 18.03. NewPhi was wrong: wrongNewPhi = ( 0.5*(Alpha[NewStartID+UseFrames] - Alpha[NewStartID]) + Phi[NewStartID+UseFrames] + Phi[NewStartID] )
    """
    # Source blocks
    BlockID = block_dialog(parent, request="Merge frames from which BlockID?", multiple=False)
    zoneblock = parent.ZoneBlock[BlockID]
    reflectionblock = parent.ReflectionBlock[BlockID]

    # New zoneblock and reflectionblock objects
    NewZoneBlock = zones.zoneblock(parent)
    NewZoneBlock.BlockID = BlockID
    NewZoneBlock.Wavelength = zoneblock.Wavelength
    NewZoneBlock.Geometry = zoneblock.Geometry
    NewZoneBlock.OM = zoneblock.OM
    NewZoneBlock.Origin = zoneblock.Origin
    NewZoneBlock.Diffrn_measurement_details = zoneblock.Diffrn_measurement_details
    NewReflectionBlock = reflections.reflectionsblock(parent)
    NewReflectionBlock.Origin = reflectionblock.Origin
    NewReflectionBlock.BlockID = BlockID
    
    # Prepare zones
    ZoneIDz = zoneblock.ZoneID
    Alpha = zoneblock.Alpha
    AlphaStep = zoneblock.AlphaStep
    Beta = zoneblock.Beta
    BetaStep = zoneblock.BetaStep
    Omega = zoneblock.Omega
    Phi = zoneblock.Phi
    UVW = zoneblock.UVW
    scale = zoneblock.scale
    if not Phi: # empty list
        Phi = [ 0 for i in range(len(Alpha)) ] # set Phi to 0 for all frames
    
    # Prepare reflections
    ZoneIDr = reflectionblock.ZoneID
    HKL = reflectionblock.HKL
    Io = reflectionblock.Io
    Isigma = reflectionblock.Isigma
    
    # Prepare integrated reflections intensities
    IoLists = dict()
    IsigmaLists = dict()
    # Loop through all reflections
    for i, hkl in enumerate(HKL): # i = index, hkl = tuple(h,k,l)
        if hkl not in IoLists:
            IoLists[hkl] = list()
            IsigmaLists[hkl] = list()
        IoLists[hkl].append(Io[i])
        IsigmaLists[hkl].append(Isigma[i])
    # Reflections with same hkl are now in separated lists
    # Calculate fully integrated Io, and new sigma
    IoInt = dict()
    IsigmaInt = dict()
    #test = (3,1,-4) 
    for hkl, IoList in IoLists.items():
        IoInt[hkl] = sum(IoList)
        #if hkl == test:
        #    print(IoList)
        #    print(IoInt[test])
    for hkl, SigmaList in IsigmaLists.items():
        IsigmaInt[hkl] = sqrt(sum(s**2 for s in SigmaList))
       
    #print(IoInt[test])
    #print(IsigmaInt[test])
    
    # MERGE SETTINGS
    Message = """MERGE SETTINGS
                 A new frame NF will include a certain number of source frames SF.
                 NFs are not generated if they do not comply with the merge settings.
                 If the parameter is set to 0 it is ignored.\n
                 Frames_Merge_MIN: minimum number of SF for NF
                 Frames_Merge_MAX: maximum number of SF for NF (must be > 1)
                 Frames_Step_MIN: minimum number of SF between the first SFs of two NFs
                 AlphaOverlap_MAX: maximum overlap of two NFs (°)
                 AlphaStep_MAX = 0.2: maximum AlphaStep between two SF for NF (°)
                 BetaStep_MAX = 0.1: maximum BetaStep between two SF for NF (°)
                 Phi_MIN = 0.3: minimum phi angle of NF (°)
                 Phi_MAX = 1.4: maximum phi angle of NF (°)\n"""
    Message = """MERGE SETTINGS
                 A new frame NF will include a certain number of source frames SF.
                 NFs are not generated if they do not comply with the merge settings.\n
                 s: exact number of SF between two NFs (int)
                 m: exact number of merged SF for one NF (int)
                 p: two numbers, target range of final phi angles (°) (°)
                 o: target overlap between two subsequent NFs (°)
                 A: maximum AlphaStep between two SF (°)
                 B: maximum BetaStep between two SF (°)
                 skip: skip every nth frame (int)
                 Examples:
                 a) ' s 5 m 10 ' = merge 10 frames in steps of 5 frames.
                 b) ' s 5 p 0.3 0.6' = merge frames until 0.3 < phi < 0.6 in steps of 5 frames.
                 c) ' p 0.3 0.9  o 0.5  A 0.3 ' = stop merging if AlphaStep > 0.3 or phi > 0.9, exclude if phi < 0.3\n"""                 
    #Message += "Example for 0.1° fine sclicing: 5 30 
    #Answer = parent.input_dialog(request=Message, default="5 30 3    1.0 0.2 0.1    0.3 1.8", title="Settings for merging frames", parameters=8)
    
    # DEFINE MERGE CONFIGURATION:
    Parameters = {"step": False, "merge": False, "overlap": False, "phimin": False, "phimax": False,
                  "AlphaStepLimit": False, "BetaStepLimit": False, "skip": 0}
    AnswerInput = parent.input_dialog(request=Message, default="s 10 m 20", title="Settings for merging frames")
    Answer = AnswerInput.split()
    if "s" in Answer:
        Parameters["step"] = int(Answer[Answer.index("s")+1])
    elif "o" in Answer:
        Parameters["overlap"] = float(Answer[Answer.index("o")+1])
    else:
        parent.log(entry="Invalid merge configuration. 's' or 'o' required. "+AnswerInput)
        return False         
    if "m" in Answer:
        Parameters["merge"] = int(Answer[Answer.index("m")+1])
        # Always merge a fixed number of frames. A B o p will be ignored.
    elif "p" in Answer:
        Parameters["phimin"] = float(Answer[Answer.index("B")+1])
        Parameters["phimax"] = float(Answer[Answer.index("B")+2])
        if "A" in Answer:
            Parameters["AlphaStepLimit"] = float(Answer[Answer.index("A")+1])
        if "B" in Answer:
            Parameters["BetaStepLimit"] = float(Answer[Answer.index("B")+1])
    else:
        parent.log(entry="Invalid merge configuration. 'm' or 'p' required. "+AnswerInput)
        return False
    if "skip" in Answer:
        Parameters["skip"] = int(Answer[Answer.index("skip")+1])
    
    NFrames = len(zoneblock.Alpha)
    NewZoneID = 1
    Pointer = 1
    SkipCounter = 0
    SkipMessage = ""
    
    while Pointer < NFrames:
        # Assume AlphaStep > 0
        NewStartID = ZoneIDz.index(Pointer)
        FrameMessage = ""
        # Determine UseFrames = number of frames to be merged
        if Parameters["merge"]: # CASE 1: number is constant
            if Pointer + Parameters["merge"] - 1 > NFrames: # end of data set reached
                print("End of data set reached:", Pointer + Parameters["merge"] - 1, " > ",  NFrames, " = number of total frames." )
                break
            UseFrames = Parameters["merge"]
        elif Parameters["phimin"]: # CASE 2: variable depending on phi, alpha etc.
            UseFrames = 1
            while Pointer + UseFrames <= NFrames:
                NewPhi = ( 0.5*sum(AlphaStep[NewStartID:NewStartID+UseFrames-1]) + Phi[NewStartID+UseFrames-1] )
                if NewPhi <= Parameters["phimax"]:
                    UseFrames += 1
                else:
                    UseFrames -= 1 # last frame exceeded phi limit
                    break
            # Check if any frame exceeds the alpha or beta step limit.
            if Parameters["AlphaStepLimit"] or Parameters["BetaStepLimit"]:
                Jumps = []
                if Parameters["AlphaStepLimit"]:
                    Steps = AlphaStep[NewStartID:NewStartID+UseFrames]
                    Jumps = [ Steps.index(i) for i in Steps if i > Parameters["AlphaStepLimit"] ]
                if Parameters["BetaStepLimit"]:
                    Steps = BetaStep[NewStartID:NewStartID+UseFrames]
                    Jumps = Jumps + [ Steps.index(i) for i in Steps if i > Parameters["BetaStepLimit"] ]
                if Jumps:
                    UseFrames = min(Jumps)
                    FrameMessage += " TiltJump limit."
                    
            # Check phimin
            NewPhi = ( 0.5*sum(AlphaStep[NewStartID:NewStartID+UseFrames-1]) + Phi[NewStartID+UseFrames-1] )
            #if NewPhi < Parameters["phimin"]:
            #    SkipCounter += 1
            #    SkipMessage += str(NewStartID)+" ("+str(UseFrames)+")  "
            #    Pointer += 1 # ZoneID pointer
            #    continue
        
        # Print out info on frames skipped since last merged frame
        if SkipCounter > 0:
            print("SKIP "+str(SkipCounter)+" potential frames: "+SkipMessage)
            SkipMessage = ""
            SkipCounter = 0
            
        # Z O N E   -   Calculate new zone parameters
        NewAlpha = sum(Alpha[NewStartID:NewStartID+UseFrames])/UseFrames
        NewBeta = sum(Beta[NewStartID:NewStartID+UseFrames])/UseFrames
        NewOmega = sum(Omega[NewStartID:NewStartID+UseFrames])/UseFrames
        #NewPhi = ( 0.5*sum(AlphaStep[NewStartID:NewStartID+UseFrames-1]) + Phi[NewStartID+UseFrames-1] )
        NewPhi = sum(Phi[NewStartID:NewStartID+UseFrames]) # UseFrames*Phi[...]
        #if NewPhi == 0:
        #    NewPhi = 1    
        NewUVW =  tuple([ sum([triple[i] for triple in UVW[NewStartID:NewStartID+UseFrames]])/UseFrames for i in range(3) ])
        if scale:
            NewScale = sum(scale[NewStartID:NewStartID+UseFrames])/UseFrames
            NewZoneBlock.scale.append(NewScale)
        # Update zone object with new zone parameters
        NewZoneBlock.ZoneID.append(NewZoneID)
        NewZoneBlock.Alpha.append(NewAlpha)
        NewZoneBlock.Beta.append(NewBeta)
        NewZoneBlock.Omega.append(NewOmega)
        NewZoneBlock.Phi.append(NewPhi)
        NewZoneBlock.UVW.append(NewUVW)
        NewZoneBlock.MergedFrames.append(UseFrames)
               
        # R E F L E C T I O N S
        # until 23.09.2020: only sum up reflections with same hkl from frames in the selected frame range
        # new style: sum up reflections with same hkl from all frames
        
        ReflectionIndices = { i for i, value in enumerate(ZoneIDr) # All reflections on the new frame, i = index, value = ZoneID
                                if (value%(Parameters["skip"]+1) == 0 and 
                                    Pointer <= value and 
                                    value < Pointer+UseFrames) } # until 08.01.2021: value <= Pointer+UseFrames
                                
        if NewZoneID == 5:
            print( { value for i, value in enumerate(ZoneIDr) # i = index, value = ZoneID
                                if (value%(Parameters["skip"]+1) == 0 and 
                                    Pointer <= value and 
                                    value < Pointer+UseFrames) } ) # until 08.01.2021: value <= Pointer+UseFrames
        # Sort reflections
        FrameIo = dict() # keys: hkl tuples. values: set of Io values. {(h1,k1,l1): {Io1, Io2,...,Ion},  (h2,k2,l2): {Io1, Io2}, ...}
        FrameIsigma = dict() # keys: hkl tuples. values: set of Isigma values.
        for i in ReflectionIndices:
            if HKL[i] not in FrameIo:
                FrameIo[HKL[i]] = IoInt[HKL[i]] # fully integrated intensities instead of I from frame selection
                FrameIsigma[HKL[i]] = IsigmaInt[HKL[i]]
                #FrameIo[HKL[i]] = set()
                #FrameIsigma[HKL[i]] = set()
            #FrameIo[HKL[i]].add(Io[i])
            #FrameIsigma[HKL[i]].add(Isigma[i])
                
        # Update ReflectionBlock object
        for iHKL, IoList in FrameIo.items():
            NewReflectionBlock.h.append(iHKL[0])
            NewReflectionBlock.k.append(iHKL[1])
            NewReflectionBlock.l.append(iHKL[2])
            NewReflectionBlock.HKL.append(iHKL)
            NewReflectionBlock.ZoneID.append(NewZoneID)
            #NewIo = sum(IoList) # Calculate merged reflection intensity
            NewIo = IoList 
            NewReflectionBlock.Io.append( NewIo ) 
            #NewSigma = sqrt(sum(s**2 for s in FrameIsigma[iHKL])) # Calculate merged Isigma sqrt(sum: sigma^2)
            NewSigma = FrameIsigma[iHKL]
            NewReflectionBlock.Isigma.append( NewSigma ) 
            if NewZoneID == 5:
                print(f"{NewIo:10.1f}, {NewSigma:6.1f}, {IoList}, {iHKL}")
        print(f"Frame {NewZoneID} ({Pointer}/{NFrames}): {UseFrames} frames. "+FrameMessage)            
        # Update pointer respecting AlphaOverlap_MAX and Frames_Step_MIN
        # b) Number must be determined based on "o"
        if Parameters["step"]: # Case 1: Constant step number, defined by "s"
            Pointer += Parameters["step"]
        elif Parameters["overlap"]:
            i = 0
            Overlap = 0
            while Overlap < Parameters["overlap"]:
                i += 1
                Overlap = (Alpha[NewStartID+UseFrames] - Alpha[NewStartID+UseFrames-i] 
                           + Phi[NewStartID+UseFrames] + Phi[NewStartID+UseFrames-i] )
            if i >= UseFrames: # avoid going backwards
                i = 2
            Pointer += i - 1
        NewZoneID += 1
        
    NewBlockID = implement_block(parent, NewZoneBlock, NewReflectionBlock)
    Path, Job = split_path_job(NewZoneBlock.Origin)
    OutputFile = Path+Job + "_" + AnswerInput.replace(" ","") + ".cif_pets"
    export_cif_pets(NewZoneBlock, NewReflectionBlock, 
                    comment="# "+str(Parameters)+"\n# "+AnswerInput,
                    outputfile=OutputFile)
    parent.log(entry="New blocks of merged frames written (BlockID "+str(NewBlockID)+") and exported as cif_pets.")
    parent.status()
    return True
 
# 4 20 3    0.6 0.15 0.06    0.3 2.1
###############################################################################
# E X P O R T
###############################################################################
def block_log(parent, event=None, output="log"):
    " Output all information stored in the block object. Allow output as logfile or in log window"
    BlockIDs = block_dialog(parent, request="Which block(s)?", multiple=True)
    PrintLength = parent.input_dialog(title="Limit output", parameters=1, default="100",
                         request="Print how many reflections (per block)?\n"+
                                 "'all' or input <= 0 will print all reflections.")
    PrintLength = -1 if PrintLength in ("", "all","All") else int(PrintLength)
    Log = dict()
    parent.log(entry="\nD y n R o c k   Block Output")
    Log["ZoneBlock"] = ""
    Log["ReflectionBlock"] = ""
    print(BlockIDs)
    print("Write log ... ", end="")
    for BlockID in BlockIDs:
        #print("Block", BlockID)
        for Type in ("ZoneBlock", "ReflectionBlock"):
            #parent.log(entry=Type+str(BlockID))
            if BlockID not in getattr(parent, Type):
                #parent.log(entry="Block "+str(BlockID)+" without "+str(Type))
                continue
            Log[Type] += "\n"+Type+str(BlockID) + " ."*42 + "\n"
            Block = getattr(parent, Type)[BlockID]
            Keys = Block.__dict__.keys()
            FloatLists = []
            IntLists = []
            StrLists = []
            Parameters = []
            Length = len(Block.ZoneID)
            if not Block.ZoneID: # M80 file
                Length = len(Block.h)
            
            # Determine columns
            for Key in Keys:
                Item = Block.get(Key)
                # ignore some entries
                if Item == None or Item == [] or Key in ("HKL","XYZ","Mother","M80Line","DI_over_sigma", "M80Fo", "M80Fc"):
                    continue
                elif type(Item) is list:
                    if len(Item) == Length:
                        ListTypes = { type(i) for i in Item[:30] }
                        if float in ListTypes:
                            FloatLists.append(Key)
                        elif int in ListTypes:
                            IntLists.append(Key)
                        else:
                            StrLists.append(Key)
                    else:
                        Log[Type] += Key+" has only "+str(len(Item))+" instead of "+str(Length)+" entries.\n"
                else:
                    Parameters.append(Key) # no list, any parameter
                    
            for Item in Parameters: # parameter labels
                Log[Type] += Item+" "+str(Block.get(Item))+"\n"
            #Log[Type] += "\n"
            HeadLine = ""
            for Item in IntLists: # int parameter values
                HeadLine += "{:>5.5} ".format(Item)
            for Item in FloatLists: # float parameter values
                HeadLine += "{:>10.10} ".format(Item) #{:>8.8}
            for Item in StrLists:
                HeadLine += Item+"  "
            HeadLine += "\n"
            Log[Type] += HeadLine
            for i in range(Length):
                if i == PrintLength and Type == "ReflectionBlock":
                    break
                for Item in IntLists:
                    try:
                        Log[Type] += "{:>5d} ".format(Block.get(Item)[i])
                    except:
                        Log[Type] += str(Block.get(Item)[i])
                for Item in FloatLists:
                    ff = "{:10.4f} "
                    if "I" in Item: # intensity
                        ff = "{:10.2f} "
                    try:
                        Log[Type] += ff.format(Block.get(Item)[i])
                    except:
                        Log[Type] += str(Block.get(Item)[i])
                for Item in StrLists:
                    Log[Type] += str(Block.get(Item)[i])
                Log[Type] += "\n"
            Log[Type] += HeadLine
    parent.log(entry=Log["ZoneBlock"]+Log["ReflectionBlock"])
    print("OK")
    return True
            
                
def export_for_completeness(parent, event=None):
    # Make new dataset with all reflections
    IDs = list(parent.ReflectionBlock.keys())
    #if len(IDs) < 2:
    #    parent.log(entry="This function makes no sense with less than 2 blocks. Nothing exported...")
    #    return False
    NewBlockID = max(IDs) + 10
    NewBlock = reflections.reflectionsblock(parent)
    NewBlock.BlockID = NewBlockID
    NewBlock.Origin = "completeness only!"
    Folder, Job = split_path_job(parent.ReflectionBlock[IDs[0]].Origin)
    for ID in IDs:
        OutputFile = Folder+Job+"_Block"+str(ID)+"_dyn.cif_pets"
        export_cif_pets(parent.ZoneBlock[ID], parent.ReflectionBlock[ID], outputfile=OutputFile)
        NewBlock.HKL += parent.ReflectionBlock[ID].HKL
        NewBlock.h += parent.ReflectionBlock[ID].h
        NewBlock.k += parent.ReflectionBlock[ID].k
        NewBlock.l += parent.ReflectionBlock[ID].l
        NewBlock.Io += parent.ReflectionBlock[ID].Io
        NewBlock.Isigma += parent.ReflectionBlock[ID].Isigma
        NewBlock.ZoneID += parent.ReflectionBlock[ID].ZoneID
    StrIDs = "_".join([ str(x) for x in IDs ])
    NewBlock.Origin = "Blocks: "+StrIDs+". Zones/Header/OM from Block "+str(IDs[0])+". Do not use this file for dynamical refinements. This file is useful to calculate the overall completeness."
    OutputFile = Folder+Job+"_Block"+StrIDs+".cif_pets"
    export_cif_pets(parent.ZoneBlock[IDs[0]], NewBlock, outputfile=OutputFile )
    UniqueHKL = set(NewBlock.HKL)
    
    parent.log(entry="Cif_pets files exported with "+str(len(UniqueHKL))+"/"+str(len(NewBlock.HKL))+" unique/all HKL values (P1).")
    return True    
    

def export_cif_pets(zoneblock, reflectionblock, outputfile="", comment=None):
    """ Write _dyn.cif_pets file with header, zone block and reflection block """
    if outputfile == "":
        if zoneblock.Origin:
            Path, Job = split_path_job(zoneblock.Origin)
            outputfile = Path+Job+"_DynRock_export.cif_pets"
        elif reflectionblock.Origin:
            Path, Job = split_path_job(reflectionblock.Origin)
            outputfile = Path+Job+"_DynRock_export.cif_pets"
        else:
            outputfile = "D:\\DynRock_export_dyn.cif_pets"
    fh = open(outputfile, mode="w")
    UnitCell = drm.unit_cell_parameters(zoneblock.OM)
    # Write header
    FormCell = "{:20}{:10.5f}\n"
    fh.writelines([
            "data_pets_DynRock_export\n",
            FormCell.format("_cell_length_a", UnitCell["a"]),
            FormCell.format("_cell_length_b", UnitCell["b"]),
            FormCell.format("_cell_length_c", UnitCell["c"]),
            FormCell.format("_cell_angle_alpha", UnitCell["alpha"]),
            FormCell.format("_cell_angle_beta", UnitCell["beta"]),
            FormCell.format("_cell_angle_gamma", UnitCell["gamma"]),
            FormCell.format("_cell_volume", UnitCell["V"]),
            "_diffrn_radiation_wavelength ", "{:7.5f}\n".format(zoneblock.Wavelength)
            ])
    FormUB = "{:27}{:9.5f}\n"
    fh.writelines([ 
            FormUB.format("_diffrn_orient_matrix_UB_"+str(row)+str(col), zoneblock.OM[row-1][col-1]) 
            for row in (1,2,3) for col in (1,2,3) ])
    # _diffrn_pets_omega . Is this information relevant? I assume not.
    # Write some comments
    if zoneblock.Diffrn_measurement_details:
        fh.write("_diffrn_measurement_details\n;\n")
        fh.write(zoneblock.Diffrn_measurement_details)
        fh.write(";\n")
    fh.write("\n# Original zones file: "+zoneblock.Origin)
    fh.write("\n# Original refl. file: "+reflectionblock.Origin)
    if comment:
        fh.write("\n# "+comment)
    # Write ZONES block
    fh.writelines([
            "\n\nloop_\n",
            "_diffrn_zone_axis_id\n",
            "_diffrn_zone_axis_u\n",
            "_diffrn_zone_axis_v\n",
            "_diffrn_zone_axis_w\n",
            "_diffrn_zone_axis_precession_angle\n",
            "_diffrn_zone_axis_alpha\n",
            "_diffrn_zone_axis_beta\n",
            "_diffrn_zone_axis_omega\n",
            "_diffrn_zone_axis_scale\n"
            ])
    FormZone = "{:>4d}" + "{:9.5f}"*3 + "{:10.3f}"*5 + "\n" # no scale
    for i, ZoneID in enumerate(zoneblock.ZoneID):
        UVW = zoneblock.UVW[i] if i < len(zoneblock.UVW) else (0,0,0)
        Omega = zoneblock.Omega[i] if i < len(zoneblock.Omega) else 0
        Scale = zoneblock.scale[i] if i < len(zoneblock.scale) else 1.0
        fh.write( FormZone.format( 
                ZoneID, UVW[0], UVW[1], UVW[2], 
                zoneblock.Phi[i], zoneblock.Alpha[i], zoneblock.Beta[i], Omega, Scale ) ) # 1.0 is the scale. Without it Jana import fails.
    # Write REFLECTION block
    fh.writelines([
            "\n\nloop_\n",
            "_refln_index_h\n",
            "_refln_index_k\n",
            "_refln_index_l\n",
            "_refln_intensity_meas\n",
            "_refln_intensity_sigma\n",
            "_refln_zone_axis_id\n"
            ])
    FormReflection = "{:>4d}"*3 + "{:12.2f}"*2 + "{:>6d}" + "\n" # no scale
    for i, ZoneID in enumerate(reflectionblock.ZoneID):
        fh.write( FormReflection.format( 
                reflectionblock.h[i], reflectionblock.k[i], reflectionblock.l[i], 
                reflectionblock.Io[i], reflectionblock.Isigma[i], ZoneID ) )
    print("Cif_pets file written: "+outputfile)
    fh.close()
    
    
###############################################################################    
# S T A T U S
###############################################################################
def status_zones(parent):
    Status = "ZONE DATA BLOCKS\n"
    Status += "Number of blocks: "+str(len(parent.ZoneBlock))+"\n"
    for BlockID in parent.ZoneBlock.keys():
        Block = parent.ZoneBlock[BlockID]
        Status += "Block "+str(BlockID)+" contains "
        Status += str(len(Block.Alpha))+" zones"
        if Block.InRefinement:
            Status += " ("+str(Block.InRefinement.count(0))+" excluded)"
        Status += "\n"
        Status += "  Geometry:  "+Block.Geometry+"\n" if Block.Geometry else ""
        Form = "  {:12s} {:8.2f} {:8.2f}\n"            
        for Item in ["scale", "thickness", "Alpha", "Beta", "AlphaStep", "BetaStep",
                     "Omega", "Phi", "EDphi", "EDtheta"]:
            List = list(filter(None, Block.get(Item)))
            if List:
                #print(Item)
                Status += Form.format(Item+":", min(List), max(List))
        Status += "-"*42 + "\n"
    return Status

def status_reflections(parent):
    Status = "REFLECTIONS DATA BLOCKS\n"
    Status += "Number of blocks: "+str(len(parent.ReflectionBlock))+"\n"
    for BlockID in parent.ReflectionBlock.keys():
        Block = parent.ReflectionBlock[BlockID]
        Status += "Block "+str(BlockID)+" contains "
        if Block.Nobs:
            Status += str(Block.Nobs)+"/"+str(Block.Nall)
        elif Block.Io_over_sigma:
            Nobs = str( len( [ i for i in Block.Io_over_sigma if i is not None and i >= 3] ) )
            Nall = str( len(Block.Io_over_sigma) )
            Status += Nobs+"/"+Nall
        else:
            Status += str( len(Block.Fo) )
        Status += " reflections\n"
            
        if Block.Rall:
            Form = "{}: {:5.2f}   "*3+"\n"
            Status += Form.format("Robs", Block.Robs*100, "Rall", Block.Rall*100, "wRall", Block.wRall*100)
        Empty = ""
        Form = "  {}: {:>3d}{:>3d}  "
        for Item in ("h","k","l"):
            List = Block.get(Item)
            Status += Form.format(Item, min(List), max(List))
        Status += "\n"
        Form = "  {:16s} {:7.4f} {:8.3f}\n"                
        for Item in ["Fo", "Fc", "Io_over_sigma", "DF_over_sigma",
                     "g", "d2x", "RSg", "DSg"]:
            List = set(filter(None,Block.get(Item)))
            if List:
                Status += Form.format(Item+":", min(List), max(List))
            else:
                Empty += Item+" "
        if Empty != "":
            Status += "Not loaded: "+Empty+"\n"
        Status += "-"*42 + "\n"
    return Status

###############################################################################
# F I L E S  and  F O L D E R S
###############################################################################
    
def block_dialog(parent, event=None, request="Enter BlockIDs", multiple=True):
    Blocks = set(parent.ReflectionBlock.keys()) | set(parent.ZoneBlock.keys())
    if len(Blocks) == 1:
        if multiple:
            return [list(Blocks)[0]]
        else:
            return list(Blocks)[0]
    Default = " ".join( [ str(i) for i in Blocks ] )
    if multiple:
        Request = request
    else:
        Request = request + "\n" + Default
        Default = ""
    Selection = parent.input_dialog(request=Request, default=Default, title="Block selector")
    if Selection in ("all", "All", ""):
        IDs = [ BlockID for BlockID in Blocks ]
    else: #print(type(Selection), Selection) #print(type(Blocks), Blocks)
        IDs = [ int(item) for item in Selection.split() if int(item) in Blocks ]
    if multiple:
        return IDs
    else:
        return IDs[0]
      
    
def split_path_job(fullpath):
    splitter = "\\"
    JobFile = fullpath.split(splitter)[-1]
    Extension = JobFile[-JobFile[::-1].index("."):]
    JobName = JobFile[:-len(Extension)-1]
    JobPath = fullpath[:-len(JobFile)]
    return (JobPath, JobName)


def get_jana_file_path(parent, ext):
    if ext in parent.JanaFiles: #if parent.JanaLoaded and hasattr(parent, "JanaFiles"):
        return parent.JanaPath+parent.JanaFiles[ext]
    else:
        parent.log("Jana file '"+ext+"' was not initialized/found.")
        return False


def get_jana_job_files(janafile):
    ''' Input a Jana file, e.g. "C:\job\refine.m40"
    Return a dictionary with path and existing files.
    '''
    JanaPath, JobName = split_path_job(janafile)
    Extensions = {"m40", "m42", "m50", "m80", "m83", "m90", "m95", "ref"}
    JanaFiles = dict()
    JanaFiles["path"] = JanaPath
    JanaFiles["job"] = JobName
    for ext in Extensions:
        if isfile(JanaPath+JobName+"."+ext):
            JanaFiles[ext] = JobName+"."+ext
    return JanaFiles   
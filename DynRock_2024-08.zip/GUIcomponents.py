# -*- coding: utf-8 -*-
"""
Outsources components/routines that require wx.
Hopefully improves overview and readability.
"""

import wx
import wx.lib.buttons as buttons
from os import getcwd

import dynrockcomponents as drc


class notebook_panel(wx.Panel):
    def __init__(self, parent, title="Hello"):
        wx.Panel.__init__(self, parent)
        #self.Panel = wx.Panel(self)
        self.PanelSizer = wx.BoxSizer(orient=wx.VERTICAL)
        
        self.Mother = parent.GetGrandParent()  
        self.OptionsBox = wx.StaticBoxSizer(orient=wx.VERTICAL, parent=self, label=title)
        self.PanelSizer.Add(self.OptionsBox, flag=wx.EXPAND)      
        self.SetSizer(self.PanelSizer)
        #self.Layout()
        
    def action_button(self, buttonlabel, buttonaction, sizer):
        Button = buttons.GenButton(self, label=buttonlabel)
        self.Bind(wx.EVT_BUTTON, buttonaction, Button)
        sizer.Add(Button, flag=wx.EXPAND)
        
    def action_button2(self, buttonlabel, buttonaction, sizer):
        Button = buttons.GenButton(self, label=buttonlabel)
        self.Bind(wx.EVT_BUTTON, lambda event: buttonaction, Button)
        sizer.Add(Button, flag=wx.EXPAND)        


class status_panel(notebook_panel):
    """ Load Jana/Pets job. Reset Jana/Pets job.
    Show available files.
    Show files status. (e.g. readin)
    Show available objects."""
    def __init__(self, parent, title="Status"):
        super().__init__(parent,title)
        # Action buttons
        OptionsBox1 = wx.BoxSizer(orient=wx.HORIZONTAL) #label="Load, import, reset, export"
        OptionsBox2 = wx.BoxSizer(orient=wx.HORIZONTAL) #label="Play with reflections"
        OptionsBox3 = wx.BoxSizer(orient=wx.HORIZONTAL) #label="Play with zones"

        self.action_button("Load JANA Job", lambda event: drc.init_jana_job(self.Mother), OptionsBox1)
        self.action_button("Load CIF_PETS", lambda event: drc.init_cif_pets_job(self.Mother), OptionsBox1)
        self.action_button("Load M80", lambda event: drc.load_m80_file(self.Mother), OptionsBox1)
        self.action_button("Merge M80", lambda event: drc.m80_block_manager(self.Mother), OptionsBox1)
        self.action_button("Copy Block", lambda event: drc.copy_block(self.Mother), OptionsBox1)
        self.action_button("Delete Block", lambda event: drc.reset(self.Mother), OptionsBox1)
        
        self.action_button("Update reflection geometry", lambda event: drc.update_reflection_geometry(self.Mother), OptionsBox2)
        self.action_button("Filter reflections", lambda event: drc.filter_reflections(self.Mother), OptionsBox2)
        self.action_button("Apply scales", lambda event: drc.apply_scales(self.Mother), OptionsBox2)
        self.action_button("Cif_pets:Merge frames", lambda event: drc.merge_frames(self.Mother), OptionsBox2)
        self.action_button("Cif_pets:completeness", lambda event: drc.export_for_completeness(self.Mother), OptionsBox2)
        
        self.action_button("Status", lambda event: self.Mother.status(), OptionsBox3)
        self.action_button("Print ALL", lambda event: drc.block_log(self.Mother), OptionsBox3)
        self.action_button("Geo=precession", lambda event: drc.geometry_precession(self.Mother), OptionsBox3)
        self.action_button("Geo=continuous", lambda event: drc.geometry_continuous(self.Mother), OptionsBox3)
        self.OptionsBox.Add(OptionsBox1, flag=wx.EXPAND)
        self.OptionsBox.Add(OptionsBox2, flag=wx.EXPAND)
        self.OptionsBox.Add(OptionsBox3, flag=wx.EXPAND)
        
        # Overview ZONES objects, REFLECTION objects
        self.StatusSizer = wx.BoxSizer(orient=wx.HORIZONTAL)
        self.ZonesStatus = wx.TextCtrl(self, size=(450,250), style=wx.TE_MULTILINE|wx.TE_READONLY, value="no Zones data loaded")
        self.ZonesStatus.SetFont(wx.Font(10,wx.FONTFAMILY_MODERN,wx.FONTSTYLE_NORMAL,wx.FONTWEIGHT_NORMAL, faceName="Courier New"))
        self.ReflectionsStatus = wx.TextCtrl(self, size=(450,250), style=wx.TE_MULTILINE|wx.TE_READONLY, value="no Reflection data loaded")
        self.ReflectionsStatus.SetFont(wx.Font(10,wx.FONTFAMILY_MODERN,wx.FONTSTYLE_NORMAL,wx.FONTWEIGHT_NORMAL, faceName="Courier New"))
        self.StatusSizer.Add(self.ZonesStatus)
        self.StatusSizer.Add(self.ReflectionsStatus)
                
        self.MainLog = wx.TextCtrl(self, size=(-1,900), style=wx.TE_MULTILINE|wx.TE_READONLY, value="D y n R o c k\n")
        self.MainLog.SetFont(wx.Font(10,wx.FONTFAMILY_MODERN,wx.FONTSTYLE_NORMAL,wx.FONTWEIGHT_NORMAL, faceName="Courier New"))
        
        self.PanelSizer.Add(self.StatusSizer, flag=wx.EXPAND)        
        self.PanelSizer.Add(self.MainLog, flag=wx.EXPAND)

    
    
"""    
def GUI_merge_wizard(parent):
    WizardFrame = wx.Frame(None)
    Wizard = wx.Panel(WizardFrame)
    DialogBox = wx.StaticBox(Wizard, label=title)
    DialogSizer = wx.StaticBoxSizer(DialogBox, orient=wx.VERTICAL)
    
    Parameters = ("Phi_min", "Phi_max", ")
    
        NewMinFramesN = 4      # neglect if too few frames
    NewMinPhi = 0.3
    NewMaxPhi = 2.0
    MaxAlphaOverlap = 1.0
    # step limitations
    MaxAlphaStep = 0.2
    MaxBetaStep = 0.1
    
    for Parameter in (":
        DialogSizer.Add(wx.RadioButton(Wizard, label='256 Colors', style=wx.RB_GROUP))
    DialogSizer.Add(wx.RadioButton(Wizard, label='16 Colors'))
    DialogSizer.Add(wx.TextCtrl(Wizard), flag=wx.LEFT, border=5)
    Wizard.SetSizer(DialogSizer)
    okButton = wx.Button(Wizard, label='Ok')
    closeButton = wx.Button(Wizard, label='Close')
    DialogSizer.Add(okButton)
    DialogSizer.Add(closeButton, flag=wx.LEFT, border=5)
    #okButton.Bind(wx.EVT_BUTTON, self.OnClose)
    #closeButton.Bind(wx.EVT_BUTTON, self.OnClose)
    WizardFrame.Show(True)
    print("Wizard end...")
    
    
    Dialog = wx.Dialog(None,-1, title=title)
    
    Btn_OK = wx.Button(Dialog, wx.ID_OK)
    Btn_Cancel = wx.Button(Dialog, wx.ID_CANCEL)
    Grid = wx.FlexGridSizer(3,2,5,5)
    Grid.Add(Btn_OK, 0, wx.ALIGN_RIGHT)
    Grid.Add(Btn_Cancel, 0)
"""

def menubar(parent):
    MenuStructure = (("&File",
                      ("&JANA: select job", lambda event: drc.init_jana_job(parent), "File explorer: select Jana job"),
                      ("&CIF_PETS: select file", lambda event: drc.init_cif_pets_job(parent), "File explorer: select cif_pets file"),
                      ("&PETS Profile: select file", lambda event: drc.init_reflprofiles_job(parent), "File explorer: select cif_pets file"),
                      ("&PETS Dyntmp: select file", lambda event: drc.init_dyntmp_job(parent), "File explorer: select dyntmp file"),
                      #("PTS&OPT: select file", lambda event: drc.init_ptsopt_job(parent), "File explorer: select ptsopt file"),
                      ("E&xit", parent.OnExit, "Learning by clicking.")),
                     ("Help",
                      ("&Status", parent.status, "Print out a status message on loaded jobs"),
                      ("&About", parent.OnAbout, "What am I doing here?"),
                      ("&Help", parent.OnAbout, "Wer bin ich? Und wenn ja, wie viele?")))
    MenuBar = wx.MenuBar()
    for item in MenuStructure:
        menuLabel = item[0]
        menuItems = item[1:]
        menu = wx.Menu(title='')
        for itemLabel, itemAction, itemStatus in menuItems:
            menuItem = menu.Append(-1, itemLabel, itemStatus)
            parent.Bind(wx.EVT_MENU, itemAction, menuItem)
        MenuBar.Append(menu, menuLabel)
    parent.SetMenuBar(MenuBar)
    parent.Status = parent.CreateStatusBar()

           
def GUI_file_dialog(directory=None, extension=None):
    """ File select dialog. File types are filtered.
    wx:    wildcard = "BMP and GIF files (*.bmp;*.gif)|*.bmp;*.gif|PNG files (*.png)|*.png"
    """
    #JanaExtensions = {"m40","m42","m50","m83","ref"}
    #PetsExtensions = {"pts","dat","cif_pets","ptsopt","rprofall","rprofstr"}
    WildCard = ""
    if extension:
        WildCard += "*."+extension+"|*."+extension+"|"
    WildCard += "JANA files|*.m40;*.m42;*.m50;*.m83;*.ref|"
    WildCard += "PETS files|*.cif_pets;*.ptsopt;*.dat;*.rprofall;*.rprofstr|"
    WildCard += "*.*|*.*"
    
    """WildCard += "JANA files|" # (m40, m42, m50, m83, ref)
    for Ext in JanaExtensions:
        WildCard += "*."+Ext+";"
    WildCard += "|PETS files|" # (cif_pets, rprofall, rprofstr, dat)
    for Ext in PetsExtensions:
        WildCard += "*."+Ext+";"
    WildCard += "|*.*|*.*"
    """
    if not directory:
        directory=getcwd()
    
    Dialog = wx.FileDialog(None, message="Choose a file", wildcard=WildCard,
                           defaultDir=directory)
    if Dialog.ShowModal() == wx.ID_OK:
        UserPath = Dialog.GetPath()
        print(UserPath)
        Dialog.Destroy()
        return UserPath
    else:
        Dialog.Destroy()
        return False
# -*- coding: utf-8 -*-
"""
define functions juggling with vectors
                                                   ( m11 m12 m13 )     ( a*1 b*1 c*1 )
OM = [[m11,m12,m13],[m21,m22,m23],[m31,m32,m33]] = ( m21 m22 m23 ) >>> ( a*2 b*2 c*2 )
                                                   ( m31 m32 m33 )     ( a*3 b*3 c*3 )
a* = [ e[0] for e in OM ]
b* = [ e[1] for e in OM ]
c* = [ e[2] for e in OM ]

Prefer returning (tuples) instead of [lists]
(tuples) cannot be changed once they are defined and require less pace.
[lists] can be changed, e.g. elements can be replaced or added.

2DO:
    - calculate rH rK rL of frame
    - calculate radial and tangential component of difference vector between expected XY on and observed XY on frame
"""

from math import sqrt, sin, cos, acos, atan2, asin
from math import pi as PI

NaN = float("NaN")

# R E C I P R O C A L   S P A C E   G E O M E T R Y
def xyz_from_hkl(om, hkl):
    """ xyz = OM.hkl 
        x = AS1*h + BS1*k + CS1*l
        y = AS2*h + BS2*k + CS2*l
        z = AS3*h + BS3*k + CS3*l
    hkl must be tuple (h,k,l or list [h,k,l]
    Corresponds to xyz in reciprocal space with respect to microscope reference
    coordinate system and goniometer angles at 0 degrees.
    """
    # x = OM[0][0]*hkl[0] + OM[0][1]*hkl[1] + OM[0][2]*hkl[2]
    # y = OM[1][0]*hkl[0] + OM[1][1]*hkl[1] + OM[1][2]*hkl[2]
    XYZ = [ sum([om[row][i]*hkl[i] for i in range(3)]) 
                                   for row in range(3) ]
    return tuple(XYZ)

def xyz_rotate(xyz, rotationmatrix):
    """ M.x
    apply rotationmatrix to to xyz coordinates of a point in reciprocal space.
    """
    NewXYZ = matrixproduct(rotationmatrix, column_vector(xyz))
    return row_vector(NewXYZ)


def calc_sg(wavevector, xyz):
    """ Calculate excitation error Sg, which is the distance beteen the
    ideal Ewald sphere defined by the wavevector and the coordinates xyz.
    Sg is defined in Equation (7) in Palatinus et al (2015), Acta Cryst A71, 235-244, "Structure refinement using precession electron diffraction tomography and dynamical diffraction: theory and implementation"
    doi:10.1107/S2053273315001266
    """ 
    K = wavevector
    g = xyz
    KplusG = [ K[i]+g[i] for i in range(3) ]
    Sg = ( length(K)**2 - length(KplusG)**2 ) / (2*length(K))
    return Sg


def calc_rsg(wavevector, xyz, phi, geometry="continuous", absolute=True, correct=True):
    """ RSg <= 1: reflection passes through exact Bragg condition during frame recording
        RSg > 1: exact Bragg condition not reached during frame recording
    RSg for precession is defined in Section 2.4(d) in Palatinus et al (2015), Acta Cryst A71, 235-244, "Structure refinement using precession electron diffraction tomography and dynamical diffraction: theory and implementation"
    RSg for continuous rotation method is similar, but |g| must be replaced by the distance to the projected rotation axis of the goniometer.
    By default, the absolute value is returned. With absolute=False, RSg is negative if Sg < 0 (like in reflprofiles*dat).
    
    For IEDT RSg was initially (until late 2019) calculated as RSg_wrong = RSg * |g|/AxisDistance. RSg = Sg / ( AxisDistance*semiangle ) * length(xyz)/AxisDistance
    """
    if phi == 0:
        return None
    semiangle = phi/180*PI # Precession: precession semiangle. Continuous rotation: rotation semiangle
    K = wavevector
    g = xyz
    Sg = calc_sg(K,g)   
    if geometry == "precession":
        RSg = Sg / ( length(g)*semiangle )
    elif geometry == "continuous":
        AxisDistance = calc_distance_to_x_axis(g)
        if AxisDistance < 0.000001:
            RSg = 9999999
        else:
            RSg = Sg / ( AxisDistance*semiangle ) # correct
    else:
        return False        
    if absolute:
        return abs(RSg)
    else:
        return RSg
    
def calc_rc_half_width_limit(wavevector, xyz, phi, geometry="continuous"):
    """ Delta Sg = DSG          Rocking Curve Limit = RCL
    A reflection has a certain size = reflection/rocking curve(RC) width. This function calculates
    the maximum allowed RC half-width so that the full curve is rocked on that frame.
    Calculation: 
        a) Calculate Sg of reflection AFTER rotating the crystal by an additional +- phi. The smaller value is the RCL.
    or  b) Calculate Sg of reflection. RCL = g*phi - abs(Sg)
    A small RCL indicates that the ideal reflection position is close to the border of the integrated volume.
    """
    if phi == 0:
        return None
    semiangle = phi/180*PI
    K = wavevector
    g = xyz
    Sg = calc_sg(K, g)
    if geometry == "precession":
        RCL = length(g)*semiangle - abs(Sg) 
    elif geometry == "continuous":
        AxisDistance = calc_distance_to_x_axis(g)
        RCL = AxisDistance*semiangle - abs(Sg)
    else:
        return False
    return RCL
    # Let's call it "Delta SG" = DSg

    
def calc_distance_to_x_axis(xyz):
    """ Distance to rotation axis. z || electron beam, x || goniometer tilt axis (alpha rotation), y || second tilt axis (beta rotation)
    The d2axe is the distance to the "shadow" (projection) of the rotation axis on the diffraction pattern defined in the Cartesian coordinate system by the axis (0,y,z).
    The unit is in reciprocal Angstrom.
    """
    # WRONG until 07.04.2020 return length(xyz[1:2])
    # EFFECT: only y coordinate considered, z ignored
    return length(xyz[1:3])


def calc_azimuth(xyz):
    """ 
    x    y    z    -180 ... -90 ... 0 ... 90 ... 180 azimuth angle
    +    +                             X                          
    -    +                                    X
    +    -                       X
    -    -               X    
    
    Azimuth independent of z
    atan2(azimuth) = sgn(y)*d2x/x 
    """
    #print(asin( calc_distance_to_x_axis(xyz) / length(xyz) )*180/PI )
    sgn = abs(xyz[1])/xyz[1] if xyz[1] != 0 else 1 # sgn(y) either 1 or -1
    return atan2(sgn*calc_distance_to_x_axis(xyz), xyz[0])*180/PI
    """
    Until 07.04.2020: 
    return asin( calc_distance_to_x_axis(xyz) / length(xyz) )*180/PI    
    sin(azimuth) = d2axe/|g| 
    """

def calc_wavevector(wavelength):
    return (0,0,-1/wavelength)


# C R Y S T A L L O G R A P H Y    
    
def unit_cell_parameters(OM):
    """ calculate unit cell parameters from orientation matrix
    OM must be a nested tuple (or list) with the inner tuple being the rows, the outer tuple the list of rows.
    """
    # reciprocal lattice vectors
    AS = [ e[0] for e in OM ] # a* = 1st column of OM
    BS = [ e[1] for e in OM ] # b* = 2nd column of OM
    CS = [ e[2] for e in OM ] # c* = 3rd column of OM
    
    VS = dotproduct(AS, crossproduct(BS,CS)) # V = a.(bxc)

    AD = [ 1/VS*e for e in crossproduct(BS,CS) ] # direct lattice vector a
    BD = [ 1/VS*e for e in crossproduct(CS,AS) ] # direct lattice vector b
    CD = [ 1/VS*e for e in crossproduct(AS,BS) ] # direct lattice vector c
    
    A = length(AD)
    B = length(BD)
    C = length(CD)
    
    alpha = acos(dotproduct(BD,CD)/(B*C))*180/PI
    beta = acos(dotproduct(CD,AD)/(C*A))*180/PI
    gamma = acos(dotproduct(AD,BD)/(A*B))*180/PI
    
    return { "a": A, "b": B, "c": C, 
            "alpha": alpha, "beta": beta, "gamma": gamma, "V": 1/VS }
    
def direction_cosines(OM):
    DirectionCosines = []
    for i in (0,1,2):
        vs = [ e[i] for e in OM] # a* = 1st column of OM
        for j in (0,1,2):
            DirCos = vs[j]/length(vs)
            DirectionCosines.append(DirCos)
    return DirectionCosines

def direction_angles(OM, exact=False):
    DirectionCosines = direction_cosines(OM)
    if exact:
        return [ acos(e)*180/PI for e in DirectionCosines ]
    else:
        return [ round(acos(e)*180/PI, 2) for e in DirectionCosines ]
    
def F_from_I(Iobs, Isigma):
    if Iobs <= 0:
        Fobs = 0
        Fsigma = sqrt(Isigma) # this is wrong!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    else:
        Fobs = sqrt(Iobs)
        Fsigma = 0.5*Isigma/Fobs
    return (Fobs, Fsigma)
    #Fcalc = sqrt(Icalc)

def I_from_F(Fobs, Fsigma):
    Iobs = Fobs**2    
    Isigma = 2*Fobs*Fsigma
    return (Iobs, Isigma)
    #Icalc = Fcalc**2

def calc_R_all(obslist, calclist):
    """ Calculate R_all for list of structure factors / intensities.
    """
    if len(obslist) != len(calclist):
        print("Error calculating R factor. Lists have different lengths.")
        return False
    numerator = 0
    denominator = 0
    for i in range(len(obslist)):
        numerator += abs(obslist[i] - calclist[i])
        denominator += abs(obslist[i])
    if denominator == 0:
        return NaN
    return numerator/denominator

def calc_R_factors(obslist, calclist, sigmalist):
    """ Assumes it is a list of STRUCTURE FACTORS. Otherwise, observed criteria is wrong.
    Robs, Rall, wRall
    """
    if len(obslist) != len(calclist):
        return (float("NaN"), float("NaN"), float("NaN"))
    Factor = 0.01 # instability factor
    Numerator = {"Rall":0, "wRall":0, "Robs":0}
    Denominator = {"Rall":0, "wRall":0, "Robs":0}
    for i in range(len(obslist)):
        Num = abs(obslist[i]-calclist[i])
        Denom = abs(obslist[i])
        Numerator["Rall"] += Num
        Denominator["Rall"] += Denom
        if obslist[i] > 6*sigmalist[i]: # I > 3sigma
            Numerator["Robs"] += Num
            Denominator["Robs"] += Denom
        Weight = sigmalist[i]**2 + (Factor*obslist[i])**2
        if Weight != 0:
            Weight = 1/Weight
        else:
            Weight = 0
        Numerator["wRall"] += abs(Weight*(obslist[i]-calclist[i])**2)
        Denominator["wRall"] += abs(Weight*obslist[i]**2)
    # assume denominator > 0
    Rall = Numerator["Rall"]/Denominator["Rall"] if Denominator["Rall"] > 0 else NaN
    wRall = sqrt(Numerator["wRall"]/Denominator["wRall"]) if Denominator["wRall"] > 0 else NaN
    Robs = Numerator["Robs"]/Denominator["Robs"] if Denominator["Robs"] > 0 else NaN
    return (Robs, Rall, wRall)


def standard_uncertainty(valuelist=[]):
    # sigma = sqrt[ SUM( (x_avg - x_i)^2 ) / (n-1) ]
    Mean = sum(valuelist)/len(valuelist)
    Sigma = sqrt( sum([ (Mean - xi)**2 for xi in valuelist ])/(len(valuelist)-1) )
    return (Mean, Sigma)


# V E C T O R   A L G E B R A
def dotproduct(v1, v2):
    """     V1 and V2 are lists or tuples representing two vectors of equal length
    """
    if len(v1) != len(v2):
        return False
    result = 0
    for i in range(len(v1)):
        result += v1[i]*v2[i]
    return result


def crossproduct(v1, v2):
    if len(v1) != 3 or len(v2) != 3:
        return False
    cross1 = v1[1]*v2[2] - v1[2]*v2[1]
    cross2 = v1[2]*v2[0] - v1[0]*v2[2]
    cross3 = v1[0]*v2[1] - v1[1]*v2[0]
    return (cross1, cross2, cross3)


def length(vector):
    squaresum = 0
    for e in vector:
        squaresum += e**2
    return sqrt(squaresum)


def column_vector(rowvector):
    """ for the matrix multiplication it is essential to define if the vector
    is an n x 1 matrix (column vector) or 1 x m matrix (row vector).
    Python tuples (a,b,c) are row vectors.
    The nested tuple ((x),(y),(z)) is a column vector.
    This function makes a column vector (nested tuple) out of an input row vector.
    """
    columnvector = [ (e,) for e in rowvector ]
    return tuple(columnvector)


def row_vector(columnvector):
    rowvector = [ e[0] for e in columnvector ]
    return tuple(rowvector)

 
def matrixproduct(M1,M2):
    """ M1.M2
    n_ij = SUM a_ik * b_kj
    requires that number of columns (row length) of  a  and number of rows (column height) of  b  are equal
    New size: number of rows of a, number of columns of  b
    """
    if len(M1[0]) != len(M2):
        return False
    NewMatrix = []
    for i in range(len(M1)): # loop through all rows of M1
        RowOfM1 = M1[i]
        NewRow = []
        for j in range(len(M2[0])): # loop through all columns of M2
            ColumnOfM2 = [ element[j] for element in M2 ]
            nij = 0
            for k in range(len(M2)): # loop through elements of column j of M2
                nij += RowOfM1[k]*ColumnOfM2[k]
            NewRow.append(nij)
        NewMatrix.append(tuple(NewRow))
    return tuple(NewMatrix)


def rotationmatrix(alpha=0, beta=0, gamma=0):
    """ input angles in DEGREES
    determine direction by providing the angle symbol at the function call. E.G: rotationmatrix(alpha=20)
    """
    matrix = []
    if abs(alpha) > 0.001:
        sa = sin(alpha/180*PI)
        ca = cos(alpha/180*PI)
        rotmat = ((  1,  0,  0), 
                  (  0, ca,-sa),
                  (  0, sa, ca))
        matrix.append(rotmat)        
    if abs(beta) > 0.001:
        sb = sin(beta/180*PI)
        cb = cos(beta/180*PI)
        rotmat = (( cb,  0, sb), 
                  (  0,  1,  0),
                  (-sb,  0, cb))
        matrix.append(rotmat)
    if abs(gamma) > 0.001:
        sg = sin(gamma/180*PI)
        cg = cos(gamma/180*PI)
        rotmat = (( cg,-sg,  0), 
                  ( sg, cg,  0),
                  (  0,  0,  1))
        matrix.append(rotmat)        
    if len(matrix) == 0:
        return ((1,0,0),(0,1,0),(0,0,1))
    elif len(matrix) == 1:
        return matrix[0]
    elif len(matrix) > 1:
        product01 = matrixproduct(matrix[0], matrix[1])
    if len(matrix) == 2:
        return product01
    elif len(matrix) == 3:
        return matrixproduct(product01, matrix[2])    

def dyngo_rotationmatrix(alpha=0,beta=0,omega=0,EDphi=0,EDtheta=0):
    # Gonio correction: EDphi.EDtheta.(-EDphi)
    # Gonio: Alpha.Beta
    pass

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
# TEST FUNCTIONS in dynrockmath_tests.py
    # -*- coding: utf-8 -*-
"""
PLOT window
PLOT handler
MISSING: 
    hkl / profile plotter
"""
import wx
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.figure import Figure

Colors = ["Blue", "Orange", "Green", "Red", "Purple", "Brown", "Pink", "Gray", "Yellow", "Turqouise"]
# This list corresponds to Matplotlib Colormap Set1. (default)
# Other color sets: Matplotlib ch2.4 (p252, pdfpage256) 

class plotpanel(wx.Panel):
    def __init__(self, parent, title=None):
        wx.Panel.__init__(self, parent)
        self.Mother = parent.GetGrandParent()
        #print("Mother of plotpanel: ", self.Mother)
        self.ColorID = 0
        self.LabelX = []
        self.LabelY = []
        self.Reflections = []
        self.Rall = []
        
        # PLOT OPTIONS
        SetParent = self
        DummyOptions = ("","loading ...","...")
        PlotStyleOptions = (".", "o", "v", "^", "D", "H", "8",
                            "+", "x", "X", "") #"p","h","<", ">","s", "*",
        PlotLineOptions = ("", "-", "--", ":", "-.")
                                     
        TextX = wx.StaticText(parent=SetParent, label=" X ")
        TextY = wx.StaticText(parent=SetParent, label=" Y ")
        TextBlock = wx.StaticText(parent=SetParent, label="   Block ")
        TextStyle = wx.StaticText(parent=SetParent, label="   Style ")
        TextBlank = wx.StaticText(parent=SetParent, label="   ")
        
        self.XChoice = wx.ComboBox(parent=SetParent, id=-1, value="X-axis", size=wx.DefaultSize, choices=DummyOptions, style=wx.CB_DROPDOWN)
        self.YChoice = wx.ComboBox(parent=SetParent, id=-1, value="Y-axis", size=wx.DefaultSize, choices=DummyOptions, style=wx.CB_DROPDOWN)
        
        self.BlockChoice = wx.ComboBox(parent=SetParent, id=-1, value="", size=(40,-1), choices=DummyOptions, style=wx.CB_DROPDOWN)
        self.PlotStyle = wx.ComboBox(parent=SetParent, id=-1, value=".", size=wx.DefaultSize, choices=PlotStyleOptions) #, style=wx.CB_DROPDOWN|wx.CB_READONLY)
        self.LineStyle = wx.ComboBox(parent=SetParent, id=-1, value="", size=wx.DefaultSize, choices=PlotLineOptions) # , style=wx.CB_DROPDOWN|wx.CB_READONLY#
        PlotButton = wx.Button(parent=SetParent, label=" Plot ")
        ResetButton = wx.Button(parent=SetParent, label=" Reset ")
        self.CurrentXcell = wx.TextCtrl(parent=SetParent, id=-1, value="", size=(55, -1))
        self.CurrentYcell = wx.TextCtrl(parent=SetParent, id=-1, value="", size=(55, -1))
        
        self.Ranges = wx.TextCtrl(parent=SetParent, id=-1, value="range x0 x1 y0 y1", size=(120, -1))
        AddPanelButton = wx.Button(parent=SetParent, size=(40, -1), label="+")
        #self.Bind(wx.EVT_COMBOBOX_DROPDOWN, self.update_block_ids, self.BlockChoice)
        self.Bind(wx.EVT_BUTTON, self.plot_prepare, PlotButton)
        self.Bind(wx.EVT_BUTTON, self.reset_plot, ResetButton)
        self.Bind(wx.EVT_BUTTON, self.add_plot, AddPanelButton)

        self.OptionsSizer = wx.BoxSizer(orient=wx.VERTICAL) 
        OptionsLine1 = wx.BoxSizer(orient=wx.HORIZONTAL) 
        OptionsLine1.AddMany([TextX, self.XChoice, TextY, self.YChoice,
                              TextBlock, self.BlockChoice,
                              TextStyle, self.PlotStyle, self.LineStyle,
                              PlotButton, ResetButton,
                              self.CurrentXcell, self.CurrentYcell,
                               TextBlank, self.Ranges])
        OptionsLine1.Add( (1000, 20), 1, wx.EXPAND) # expanding box to push "+" button to the right corner
        OptionsLine1.Add(AddPanelButton, flag=wx.EXPAND) #wx.ALIGN_RIGHT|
        self.OptionsSizer.Add(OptionsLine1)
        
        # CANVAS PLOT AREA
        self.figure = Figure()
        self.figure.set_tight_layout(True)
        self.axes = self.figure.add_subplot(111)
        self.axes.set_xlabel("x")
        self.axes.set_ylabel("y")
        self.canvas = FigureCanvas(self, -1, self.figure)
        self.canvas.mpl_connect('motion_notify_event', self.update_xy)
        
        self.Sizer = wx.BoxSizer(orient=wx.VERTICAL)
        self.Sizer.Add(self.OptionsSizer)
        self.Sizer.Add(self.canvas, 1, wx.EXPAND)
        self.SetSizer(self.Sizer)

    def plot_xy(self, x, y, xlabel="x", ylabel="y", xerror=[], yerror=[]):
        " Read about error bars: MatPlotLib page 866 (pdf 870) "
        Style = self.PlotStyle.GetValue()+self.LineStyle.GetValue() #GetStringSelection()
        self.axes.plot(x, y, Style)
        if xerror and yerror:
            self.axes.errorbar(x,y,xerr=xerror,yerr=yerror,fmt='none',ecolor='Black')
        elif yerror:
            self.axes.errorbar(x,y,yerr=yerror,fmt='none',ecolor='Black')
        elif xerror:
            self.axes.errorbar(x,y,xerr=xerror,fmt='none',ecolor='Black')
        self.axes.grid(0.2)
        
        # set x and y plot ranges
        Limits = self.Ranges.GetValue().split()
        if len(Limits) == 4:
            self.axes.set_xlim([float(Limits[0]), float(Limits[1])])
            self.axes.set_ylim([float(Limits[2]), float(Limits[3])])
        elif len(Limits) == 2:
            self.axes.set_xlim([0, float(Limits[0])])
            self.axes.set_ylim([0, float(Limits[1])])
            
        self.LabelX.append(xlabel)
        self.LabelY.append(ylabel)
        Xlabel, Ylabel = self.make_label()
        self.axes.set_xlabel(Xlabel)
        self.axes.set_ylabel(Ylabel)
        self.canvas.draw()
        self.ColorID += 1
        if self.ColorID == len(Colors):
            self.ColorID = 0
        if len(x) < 200:
            print(xlabel, x)
            print(ylabel, y)
                
    def reset_plot(self, event=None):
        self.LabelX = []
        self.LabelY = []
        self.Reflections = []
        self.Rall = []
        self.ColorID = 0
        self.axes.clear()
        self.axes.set_xlabel("")
        self.axes.set_ylabel("")
        self.canvas.draw()
        self.update_block_ids()
        #print("Reset plot.")
        
    def update_xy(self, event=None):
        if event.inaxes:
            Xnow,Ynow = event.xdata, event.ydata
            self.CurrentXcell.SetValue(str(Xnow))
            self.CurrentYcell.SetValue(str(Ynow))
        
    def make_label(self):
        Xitems = []
        Yitems = []
        LabelX = ""
        LabelY = ""
        for Item in self.LabelX:
            if Item not in Xitems:
                LabelX += Item + "  "
                Xitems.append(Item)
        if self.Rall:
            LabelX += "(Rall "
            for R in self.Rall:
                LabelX += R + " "
            LabelX += "/ Nall "
            for N in self.Reflections:
                LabelX += N + " "
            LabelX += ")"
        for Item in self.LabelY:
            if Item not in Yitems:
                ColorID = (len(self.LabelY) - self.LabelY[::-1].index(Item) - 1)%len(Colors)
                LabelY += Item + " (" + Colors[ColorID] + ")  "
                Yitems.append(Item)
        return (LabelX, LabelY)
    
    def update_block_ids(self, event=None):
        CurrentID = self.BlockChoice.GetValue()
        BlockIDs = [ str(i) for i in set(self.Mother.ReflectionBlock.keys()) | set(self.Mother.ZoneBlock.keys()) ]
        if len(BlockIDs) > 1:
            BlockIDs.append("all")
        BlockIDs = tuple(BlockIDs)
        self.BlockChoice.Set(tuple(BlockIDs))
        if len(str(CurrentID)) > 0:
            self.BlockChoice.SetValue(CurrentID)
        else:
            self.BlockChoice.SetValue(BlockIDs[0])
        return True
    
    def get_block_ids(self):
        Choice = self.BlockChoice.GetValue()
        if Choice == "all":
            BlockIDs = list(self.Mother.ReflectionBlock.keys())
        else:
            BlockIDs = [ int(i) for i in Choice.split() ]
        return BlockIDs

    def plot_prepare(self, event=None):
        pass
    
    def add_plot(self, event=None):
        pass

###############################################################################
###############################################################################
        
class plotzone(plotpanel):
    def __init__(self, parent, title): 
        super().__init__(parent,title)        
        options = ("ZoneID", "scale", "thickness",
                   "Alpha", "Beta", "Phi", "EDphi", "EDtheta", 
                   "AlphaStep", "BetaStep", "Overlap", 
                   "Robs", "Rall", "Nobs", "Nall")
        self.XChoice.Set(options)
        self.XChoice.SetSelection(0)     
        self.YChoice.Set(options)
        self.YChoice.SetSelection(1)
        self.LineStyle.SetValue("-")
        self.OptionsSizer.Layout()
        
    def plot_prepare(self, event=None):
        ChoiceX = self.XChoice.GetValue() #GetStringSelection()
        ChoiceY = self.YChoice.GetValue() #GetStringSelection()
        BlockIDs = self.get_block_ids()
        for BlockID in BlockIDs:
            if (not hasattr(self.Mother.ZoneBlock[BlockID], ChoiceX) or 
                not hasattr(self.Mother.ZoneBlock[BlockID], ChoiceY)):
                print("Wrong choice:", ChoiceX, "or", ChoiceY)
                continue
            x = self.Mother.ZoneBlock[BlockID].get(ChoiceX)
            y = self.Mother.ZoneBlock[BlockID].get(ChoiceY)
            self.plot_xy(x, y, xlabel=ChoiceX, ylabel=ChoiceY)        
        
    def add_plot(self, event=None):
        self.Mother.add_zone_plot()

###############################################################################
###############################################################################

class plotprofile(plotpanel):
    """ Plot profiles of a reflection hkl.
    FILTER: ZoneID
    LIST: properties
    SELECT reflection (h,k,l)    NEXT reflection   
    Calculate profile agreement factor
    """
    def __init__(self, parent, title):    
        super().__init__(parent,title)
        OptionsLine2 = wx.BoxSizer(orient=wx.HORIZONTAL)
        SetParent = self
        TextHKL = wx.StaticText(parent=SetParent, label=" hkl: ")
        self.hklChoice = wx.TextCtrl(parent=SetParent, id=-1, value="4 2 0", size=(70, -1))
        ButtonNextHKL = wx.Button(parent=SetParent, id=-1, label="Next HKL", name="NextHKL")
        TextZone = wx.StaticText(parent=SetParent, label=" Zone: ")
        self.ZoneChoice = wx.TextCtrl(parent=SetParent, id=-1, value="", size=(45, -1))
        OptionsLine2.AddMany([TextHKL, self.hklChoice, ButtonNextHKL, TextZone, self.ZoneChoice])
        self.OptionsSizer.Add(OptionsLine2)
        self.Bind(wx.EVT_BUTTON, self.next_hkl, ButtonNextHKL)
        
        Xoptions = ("Sg", "RSg", "DSg", "ZoneID")
        Yoptions = ("Fo", "Fc", "Io", "Ic", "Isigma", "I_over_sigma")
        self.XChoice.Set(Xoptions)
        self.XChoice.SetValue("Sg")
        self.YChoice.Set(Yoptions)
        self.YChoice.SetValue("Io")
        self.LineStyle.SetValue("-")
        self.OptionsSizer.Layout()
        
        
    def plot_prepare(self, event=None):
        ChoiceHKL = str2hkl(self.hklChoice.GetValue())
        ChoiceX = self.XChoice.GetValue() #GetStringSelection()
        ChoiceY = self.YChoice.GetValue() #GetStringSelection()
        BlockID = int(self.BlockChoice.GetValue())
        AllX = self.Mother.ReflectionBlock[BlockID].get(ChoiceX)
        AllY = self.Mother.ReflectionBlock[BlockID].get(ChoiceY)
        IDs = self.Mother.ReflectionBlock[BlockID].get_hkl_profile_IDs(ChoiceHKL)
        X = [ AllX[i] for i in IDs ]
        Y = [ AllY[i] for i in IDs ]
        # Sort
        OldOrder = [ (i, value) for (i, value) in enumerate(X) ]
        OldOrder.sort(key=lambda x: x[1])
        XSorted = [ element[1] for element in OldOrder ]
        YSorted = [ Y[i[0]] for i in OldOrder ]
        self.plot_xy(XSorted, YSorted, xlabel=ChoiceX, ylabel=ChoiceY) 
    
    def next_hkl(self, event=None):
        # update hklChoice field, set next hkl in Zone or global hkl
        BlockID = int(self.BlockChoice.GetValue())
        InputHKL = str2hkl(self.hklChoice.GetValue())
        ZoneID = self.ZoneChoice.GetValue()
        
        # Determine HKL pool
        if ZoneID != "":
            ZoneID = int(ZoneID)
            if ZoneID in self.Mother.ReflectionBlock[BlockID].ZoneID:
                IDs = [ i for i, zid in enumerate(self.Mother.ReflectionBlock[BlockID].ZoneID) if zid == ZoneID ]
            else:
                return False
            HKLlist = [ self.Mother.ReflectionBlock[BlockID].HKL[i] for i in IDs ] # only HKL on selected frame
            print("Zone",ZoneID, ":",HKLlist)
        else:
            HKLlist = list(set(self.Mother.ReflectionBlock[BlockID].HKL)) # all HKL in data set, set removes duplicates
        # Determine next HKL
        if InputHKL in HKLlist[:-1]:
            NewHKL = HKLlist[ HKLlist.index(InputHKL)+1 ]
        else:
            NewHKL = HKLlist[0]
        NewHKL = " ".join( [str(item) for item in NewHKL] )
        self.hklChoice.SetValue(NewHKL)
        
    def add_plot(self, event=None):
        self.Mother.add_profile_plot()

###############################################################################

class plotreflection(plotpanel):
    def __init__(self, parent, title):    
        super().__init__(parent,title)
        OptionsLine2 = wx.BoxSizer(orient=wx.HORIZONTAL)
        SetParent = self
        self.Filter = wx.TextCtrl(parent=SetParent, id=-1, value="", size=(220, -1)) #g 0 3
        self.BinChoice = wx.TextCtrl(parent=SetParent, id=-1, value="1", size=(45, -1))
        TextFilter = wx.StaticText(parent=SetParent, label=" Filter: ")
        TextBin =  wx.StaticText(parent=SetParent, label=" Bin ")
        self.TextBinNote =  wx.StaticText(parent=SetParent, label=" <-- Bin should be at least 20 for meaningful R factors.")
        OptionsLine2.AddMany([TextFilter, self.Filter, TextBin, self.BinChoice, self.TextBinNote])
        self.OptionsSizer.Add(OptionsLine2)
        
        self.options = ("ZoneID", 
                        "Fo", "Fc", "DeltaF", "wDF", "Fsigma", "Fweight", "Fo_over_sigma", "DF_over_sigma",
                        "Io", "Ic", "DeltaI", "Isigma", "Iweight", "Io_over_sigma", "DI_over_sigma",
                        "g", "d2x", "azimuth", "Sg", "DSg", "RSg") #, "obsFlag", "badFlag", "nref")
        self.XChoice.Set(self.options)
        self.XChoice.SetSelection(1)
        self.YChoice.Set(self.options[1:]) # without i, allow special option R
        self.YChoice.Append("R-factor")
        self.YChoice.SetSelection(1) # default: Fo/Fc plot
        self.Bind(wx.EVT_COMBOBOX, self.check_bin, self.YChoice)
        self.OptionsSizer.Layout()
        self.TextBinNote.Show(False)
        
        
    def plot_prepare(self, event=None):
        ChoiceX = self.XChoice.GetValue() #GetStringSelection()
        ChoiceY = self.YChoice.GetValue() #GetStringSelection()
        #Message = "(x=" + ChoiceX + " y="+ ChoiceY+")"
         
        # Check if R factor calculations are required
        CalcR = False
        if ChoiceY == "R-factor":
            CalcR = True
            ChoiceY = "ZoneID"
            
        # prepare reflection block
        BlockIDs = self.get_block_ids()
        for BlockID in BlockIDs:
            Reflections = self.Mother.ReflectionBlock[BlockID]
            if not hasattr(Reflections, ChoiceX) or not hasattr(Reflections, ChoiceY):
                print("Wrong choice:", ChoiceX, "or", ChoiceY)
                continue
            
            #print(len(Reflections.Fo))
            #print(len(Reflections.Fc))
            
    
            FinalIndices = set(range(len( Reflections.get(ChoiceX) )))
            if not len(FinalIndices):
                print(ChoiceX, "was not loaded.")
            
            # Read filter
            FilterInput = self.Filter.GetValue()
            if FilterInput != "":
                FilterInput = FilterInput.split()
                if len(FilterInput)%3 > 0:
                    print("Number of parameters divided by space(s) must be a multiple of 3.", FilterInput)
                    print(FilterInput)
                Parameters = [ element for (i, element) in enumerate(FilterInput) if i%3 == 0 and hasattr(Reflections, element)] #element in self.options
                if len(Parameters) != len(FilterInput)/3:
                    print("Filter parameter not found.", FilterInput)
                LowLimit = [ float(element) for (i, element) in enumerate(FilterInput) if i%3 == 1 ]
                HighLimit = [ float(element) for (i, element) in enumerate(FilterInput) if i%3 == 2 ]
    
                # Apply filter -> Determine indices of reflections included
                for i in range(len(Parameters)):
                    NewIndices = range_filter(Reflections.get(Parameters[i]), LowLimit[i], HighLimit[i]) # Add set of indices fulfilling the filter criteria to Indices
                    FinalIndices = FinalIndices & NewIndices # intersection
            
            # Setup X and Y list
            X = []
            Y = []
            FoFc = []
            #Fsigma = []
            Removals = set()
            for i in FinalIndices:
                if Reflections.get(ChoiceX)[i] is None or Reflections.get(ChoiceY)[i] is None:
                    Removals.add(i)
                    continue
                X.append(Reflections.get(ChoiceX)[i])
                if Reflections.Fc:
                    FoFc.append( (Reflections.Fo[i], Reflections.Fc[i]) ) # list of (Fo,Fc) tuples
                #Fsigma.append( Reflections.Fsigma[i] )
                if CalcR:
                    Y = FoFc
                else:
                    Y.append(Reflections.get(ChoiceY)[i])
            for i in Removals:
                FinalIndices.remove(i)                
                    
            # Calculate overall R factor (Rall)
            if Reflections.Fc:
                FoList = [ Item[0] for Item in FoFc ]
                FcList = [ Item[1] for Item in FoFc ]
                Rall = "{:4.1f}%".format(r_factor(FoList, FcList)*100)
                if Rall == "-100.0%":
                    Rall = "-"
            else:
                Rall = "-"
            
            # Sort X
            if ChoiceX == "i":
                XSorted = [ i for i in range(len(X)) ]
                YSorted = Y
            else:
                OldOrder = [ (i, value) for (i, value) in enumerate(X) ]
                OldOrder.sort(key=lambda x: x[1])
                XSorted = [ element[1] for element in OldOrder ]
                YSorted = [ Y[i[0]] for i in OldOrder ]           
    
            # Bin / Average 
            # later add option to accept values in %
            BinSize = int(self.BinChoice.GetValue())
            if BinSize > 1:
                i = 0
                XBin = []
                YBin = []
                while (i+1)*BinSize < len(XSorted):
                    XBin.append( avg( XSorted[i*BinSize:(i+1)*BinSize] ) )
                    if CalcR:
                        ChoiceY = "R-factor"
                        FoList = [ i[0] for i in YSorted[i*BinSize:(i+1)*BinSize] ]
                        FcList = [ i[1] for i in YSorted[i*BinSize:(i+1)*BinSize] ]
                        YBin.append(r_factor(FoList, FcList))
                    else:
                        YBin.append( avg( YSorted[i*BinSize:(i+1)*BinSize] ) )
                    i += 1
                # reflections of the last incomplete bin are excluded
                # include them? XBin.append( avg( XSorted[i*BinSize:] ) ); YBin.append( avg( YSorted[i*BinSize:] ) )
            else:
                XBin = XSorted
                YBin = YSorted
                if CalcR: # R factor of single reflection should not be really used ...
                    ChoiceY = "R-factor"
                    YBin = []
                    for Fo, Fc in YSorted:
                        if Fo != 0:
                            YBin.append((Fo-Fc)/Fo)
                        else:
                            YBin.append(None)
            #Message = " Plot " + str(len(XBin)) + " " + Colors[self.ColorID%10] + " points. " + Message
            XLabel = ChoiceX # NONE type still considered...
            self.Reflections.append(str(len(FinalIndices)))
            self.Rall.append(Rall)
            self.plot_xy(XBin, YBin, xlabel=XLabel, ylabel=ChoiceY)           
        
    def check_bin(self, event=None):
        if self.YChoice.GetValue() == "R-factor":
            if int(self.BinChoice.GetValue()) < 10:
                self.TextBinNote.Show(True)
        else:
            self.TextBinNote.Show(False)
        self.OptionsSizer.Layout()
        
        
    def add_plot(self, event=None):
        self.Mother.add_reflection_plot()  
        
    
        
def avg(inputlist):
    return sum(inputlist)/len(inputlist)

def r_factor(fobslist, fcalclist):
    """ Calculate R factor for list of structure factors of Fobs and Fcalc.
    If lists contain values of F^2 = intensitiy, then it is the R(F2) factor.
    It is required that fobslist[i] and fcalclist[i] belong to the same hkl"""
    if len(fobslist) != len(fcalclist):
        print("Error calculating R factor. Lists have different lengths.")
        return False
    numerator = 0
    denominator = 0
    for i in range(len(fobslist)):
        numerator += abs(fobslist[i] - fcalclist[i])
        denominator += abs(fobslist[i])
    if denominator == 0:
        return -1
    return numerator/denominator

def range_filter(inputlist, lowerlimit, upperlimit):
    """ determine values in inputlist that lie within the given limits.
    Return a set of indices.
    """
    if lowerlimit == "" and upperlimit == "":
        return set([ i for i in range(len(inputlist)) ])
    if lowerlimit == "":
        LowerLimit = min(inputlist)
    else:
        LowerLimit = float(lowerlimit)
    if upperlimit == "":
        UpperLimit = max(inputlist)
    else:
        UpperLimit = float(upperlimit)
    return { i for i, value in enumerate(inputlist) 
            if value is not None and LowerLimit <= value and value <= UpperLimit }
    
def str2hkl(hkl):
    ''' Convert a string "h k l" into a tuple (h,k,l)
    '''
    HKL = hkl.split()
    if len(HKL) == 3:
        return tuple([int(i) for i in HKL])
    else:
        return False    

"""
plt[pltid].plot(xP,yRF,"-o")
plt[pltid].grid(0.2)
fig.suptitle("partial R factors (g, d, amp, RSg) with Rall "+str(Rall)+")", fontsize=21)    
fig.savefig(dataset+jobname+"\\R.png")
"""
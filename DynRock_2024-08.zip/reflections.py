#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
JANA ref functions
=====================
+ extract:
    equations induced by symmetry
    Fo Fc sigma(Fo) obs# worst_fit* frame
    ? EDscale(s.u.)
    "Last screen information window"
    Time spent in Jana/Dyngo

+ plot R factors for different shells
+ calculate R factors for octants
+ calculate d2x
+ calculate to which extent a reflection is integrated on the frame

ref object:
file, run parameters, wavelength,
reflections[{"hkl" "Fo" "Fc" "sigma" "frame" "obsflag" "badflag"  }]

'''
import dynrockmath as drm
from math import sqrt

# parent.ReflectionBlock[1] = object
NaN = float("NaN")

class reflectionsblock:
    def __init__(self, parent):
        self.Mother = parent
        self.Origin = None # file from which reflections were imported
    
        self.BlockID = None
        self.JanaBlockID = None
        self.h = []
        self.k = []
        self.l = []
        self.HKL = []
        self.ZoneID = []
        self.OnNframes = []
        
        self.Fo = []
        self.Fc = []
        self.Fsigma = []
        self.Fweight = []
        self.Fo_over_sigma = []
        self.DF_over_sigma = []
        self.wDF = [] # weighted DF
        self.DeltaF = [] # added 09.08.2022
        
        self.Scale = []
        
        self.Io = []
        self.Ic = []
        self.Isigma = []
        self.Io_over_sigma = []
        self.DI_over_sigma = []
        self.DeltaI = [] #added 09.08.2022
        
        self.ObsFlag = []
        self.nref = []
        
        self.x = []
        self.y = []
        self.z = []
        self.XYZ = []
        self.g = []
        self.d2x = []
        self.azimuth = []
        self.Sg = []
        self.RSg = []
        self.DSg = []
        #self.RSg_old = []
        
        self.Wavelength = None
        
        self.Nobs = None # number of observed reflections in overall block
        self.Nall = None
        self.Robs = None
        self.Rall = None
        self.wRall = None
        
        self.MergedFrames = None
        self.MergeStepFrames = None
        
        self.M80Line = [] # useful for rewriting M80 blocks
        self.M80Factor = [] # 13th column in M83. Fc(M80) = M80Factor*Fc(REF) = M80Factor*sqrt(Ic(M83))
        self.M80Fo = []
        self.M80Fc = []
        
        
    def get(self, parameter):
        return getattr(self, parameter)        
        
    def get_hkl_profile_IDs(self, hkl=(1,0,0)):
        return [ i for i, triple in enumerate(self.HKL) if triple == hkl]
        #if hkl not in self.HKL:
        #    self.Mother.log("Reflection not found.") # also write out HKL
        #    return False
    
    def convert_IF(self, event=None):
        if len(self.Fo) == len(self.Io): # both loaded or none loaded
            return False
        if len(self.Fo) > len(self.Io): # calculate intensity from structure factors
            for i, Fo in enumerate(self.Fo):
                Iobs = Fo**2
                Isigma = 2*Fo*self.Fsigma[i]
                Iobs_over_sigma = Iobs/Isigma if Isigma > 0 else NaN
                self.Io.append(Iobs)
                self.Isigma.append(Isigma)
                self.Io_over_sigma.append(Iobs_over_sigma)
                if self.Fc: #
                    Icalc = self.Fc[i]**2
                    DeltaI_over_sigma = (Iobs-Icalc)/Isigma if Isigma > 0 else NaN
                    self.Ic.append(Icalc)
                    self.DI_over_sigma.append(DeltaI_over_sigma)
                    self.DeltaI.append(Iobs-Icalc) # August 2022
        else: # calculate structure factors from intensity
            for i, Iobs in enumerate(self.Io):
                Isigma = self.Isigma[i]
                Fobs = sqrt(Iobs) if Iobs >= 0 else 0
                Fsigma = 0.5*Isigma/sqrt(abs(Iobs)) if Iobs != 0 else 0.5*Isigma   ### HOW TO ESTIMATE Fsigma
                Fobs_over_sigma = Fobs/Fsigma if Fsigma > 0 else NaN
                self.Fo.append(Fobs)
                self.Fsigma.append(Fsigma)
                self.Fo_over_sigma.append(Fobs_over_sigma)
                if self.Ic: # list not empty
                    Fcalc = sqrt(self.Ic[i])
                    DeltaF_over_sigma = (Fobs-Fcalc)/Fsigma if Fsigma > 0 else NaN
                    self.DeltaF.append(Fobs-Fcalc)
                    #Weight = 1/sqrt(Fsigma^2 + (0.01*Fobs)^2) if Fsigma > 0 else NaN
                    wDF = self.Fweight[i]*(Fobs-Fcalc)
                    self.Fc.append(Fcalc)
                    self.DF_over_sigma.append(DeltaF_over_sigma)
                    self.wDF.append(wDF)
        return True
    
    def m80_fo_fc(self, event=None, normalize=True):
        # [X] Rescale to Fcalc: Fc(M80) = sqrt( Re(Fc)^2+Im(Fc)^2/Fc(ref) )
        # [ ] Without rescale:  Fc(M80) = sqrt( avg_scale/scale_i )*Fc(ref)
        if not self.M80Factor:
            return False
        self.M80Fc = []
        self.M80Fo = []
        for i, Fo in enumerate(self.Fo):
            self.M80Fo.append( Fo*self.M80Factor[i] )
            self.M80Fc.append( self.Fc[i]*self.M80Factor[i] )
        return True


    def calc_hkl_geometry(self, event=None):
        """ from OM and frame orientation (requires loading M42 file)
        calculate reflection properties
        """
        if self.BlockID not in self.Mother.ZoneBlock or not self.ZoneID:
            print("Zone parameters for this block are not available.")
            if 1 in self.Mother.ZoneBlock:
                OM = self.Mother.ZoneBlock[1].OM
                #self.XYZ = []
                self.g = []
                self.d2x = []
                for hkl in self.HKL:
                    XYZ = drm.xyz_from_hkl(OM, hkl)
                    self.g.append(drm.length(XYZ))
                    self.d2x.append(drm.calc_distance_to_x_axis(XYZ))
                return True
            else:
                return False
        ZoneBlock = self.Mother.ZoneBlock[self.BlockID]
        if not self.Wavelength and not ZoneBlock.Wavelength:
            return False
        Lambda = self.Wavelength if self.Wavelength else ZoneBlock.Wavelength
        K = drm.calc_wavevector(Lambda) # wavevector
        Geometry = ZoneBlock.Geometry
        if not Geometry:
            Geometry = "precession"
        print("Update reflection geometry. Mode: "+Geometry)
        OM = ZoneBlock.OM
        # Reset values
        self.x = []
        self.y = []
        self.z = []
        self.XYZ = []
        self.g = []
        self.Sg = []
        self.d2x = []
        self.azimuth = []
        self.RSg = []
        self.DSg = []
        #self.RSg_old = []
        
        for i, ZoneID in enumerate(self.ZoneID):
            ZoneI = ZoneBlock.ZoneID.index(ZoneID)
            Alpha = ZoneBlock.Alpha[ZoneI]
            Beta = ZoneBlock.Beta[ZoneI]
            Phi = ZoneBlock.Phi[ZoneI]            
            EDphi = ZoneBlock.EDphi[ZoneI] if ZoneBlock.EDphi else 0        # not defined if imported from cif_pets
            EDtheta = ZoneBlock.EDtheta[ZoneI] if ZoneBlock.EDtheta else 0  # not defined if imported from cif_pets
            
            XYZ = drm.xyz_from_hkl(OM, self.HKL[i])
            self.x.append(XYZ[0])
            self.y.append(XYZ[1])
            self.z.append(XYZ[2])
            self.XYZ.append(XYZ)
            self.g.append(drm.length(XYZ))
            Ralpha = drm.rotationmatrix(alpha=Alpha)
            Rbeta = drm.rotationmatrix(beta=Beta)
            GoniometerRotation = drm.matrixproduct(Ralpha, Rbeta)
            if EDphi != 0 or EDtheta != 0:
                Rphi = drm.rotationmatrix(gamma=EDphi)
                Rtheta = drm.rotationmatrix(beta=EDtheta)
                R_phi = drm.rotationmatrix(gamma=-EDphi) # negative phi
                GoniometerCorrection = drm.matrixproduct(drm.matrixproduct(Rphi,Rtheta),R_phi) # (Rphi.Rtheta).R_phi
                RotationMatrix =  drm.matrixproduct(GoniometerCorrection, GoniometerRotation)  # [(Rphi.Rtheta).R_phi].(Ralpha.Rbeta)
            else:
                RotationMatrix = GoniometerRotation
            RotatedXYZ = drm.xyz_rotate(XYZ, RotationMatrix)
            self.Sg.append(drm.calc_sg(K, RotatedXYZ))
            self.d2x.append(drm.calc_distance_to_x_axis(RotatedXYZ))
            self.azimuth.append(drm.calc_azimuth(RotatedXYZ))
            self.RSg.append(drm.calc_rsg(K, RotatedXYZ, Phi, geometry=Geometry, correct=True))
            self.DSg.append(drm.calc_rc_half_width_limit(K, RotatedXYZ, Phi, geometry=Geometry)) # Delta Sg, Rocking curve half width limit
        return True            
            

    def calc_r(self, event=None):
        # #  calculate R factors for data set and individual zones
        # #  If Fc and/or Ic data not available, determine Nobs and Nall
        # GLOBAL R factor of complete block
        self.Nall = len(self.Fo)
        if self.Fsigma:
            self.Nobs = len( [ f for f in self.Fo_over_sigma if f >= 6  ] )
            self.Robs, self.Rall, self.wRall = drm.calc_R_factors(self.Fo, self.Fc, self.Fsigma)
        else:
            self.Rall = drm.calc_R_all(self.Fo, self.Fc, self.Fsigma)
        
        # R factors of INDIVIDUAL ZONES
        if self.BlockID in self.Mother.ZoneBlock: # and self.Fc and self.Fsigma
            ZoneBlock = self.Mother.ZoneBlock[self.BlockID]
            # check that ZoneBlock is empty.
            ZoneBlock.Robs = []
            ZoneBlock.Rall = []
            ZoneBlock.wRall = []
            ZoneBlock.Nobs = []
            ZoneBlock.Nall = []
            # Loop through the ZoneIDs 
            for zID in ZoneBlock.ZoneID:
                rID = [ i for i, zonid in enumerate(self.ZoneID) if zonid == zID ]
                if not rID:
                    ZoneBlock.Robs.append(float("NaN"))
                    ZoneBlock.Rall.append(float("NaN"))
                    ZoneBlock.wRall.append(float("NaN"))
                    ZoneBlock.Nobs.append(0)
                    ZoneBlock.Nall.append(0)
                    continue
                # determine Nobs, Nall
                ZoneBlock.Nall.append(len(rID))
                FoList = [ self.Fo[i] for i in rID ]
                if self.Fc:
                    FcList = [ self.Fc[i] for i in rID ]
                else:
                    ZoneBlock.Rall.append(float("NaN"))
                if self.Fsigma:
                    FsList = [ self.Fsigma[i] for i in rID ]
                    FosList = [ self.Fo_over_sigma[i] for i in rID ]
                    ZoneBlock.Nobs.append( len([ f for f in FosList if f >= 6  ]) )
                    if self.Fc:
                        Robs, Rall, wRall = drm.calc_R_factors( FoList, FcList, FsList )
                        ZoneBlock.Rall.append(Rall)
                        ZoneBlock.Robs.append(Robs)
                        ZoneBlock.wRall.append(wRall)
                else:
                    ZoneBlock.Nobs.append(0)
                    ZoneBlock.Robs.append(float("NaN"))
                    ZoneBlock.wRall.append(float("NaN"))
        return True
    
    def skip_r(self, event=None):
        best = 1
        for step in range(2,15):
            for off in range(step):
                Fos = [ abs(self.Fo[i]) for i, z in enumerate(self.ZoneID) if z%step == off ]
                DFs = [ abs(self.Fo[i]-self.Fc[i]) for i, z in enumerate(self.ZoneID) if z%step == off ]
                Rall = sum(DFs)/sum(Fos) if sum(Fos) > 0 else 0
                if best > Rall:
                    best = Rall
                print("{:3d} {:3d} {:6.2f}".format(step, off, Rall*100))
        print("Best R factor: ", best*100)


    def filter_reflections(self, event=None, parameters=[], lowlimit=[], highlimit=[]):
        """ Filter reflections. Reflections not passing the filter are deleted!
        Consider creating a copy of the object first.
        Results can the be exported (e.g. export dyn.cif_pets file)
        """
        # Prepare filters
        Parameters = parameters
        LowLimit = lowlimit
        HighLimit = highlimit
        if len(Parameters) != len(LowLimit) != len(HighLimit):
            return False
        # Filter summary        
        self.log("** BLOCK "+str(self.BlockID)+" **")
        for (i, P) in enumerate(Parameters):
            self.log( "FILTER "+str(LowLimit[i])+" <= "+str(P)+" <= "+str(HighLimit[i]) )
        # Determine which parameters are affected, e.g. if Fc is loaded or is an empty list
        DeleteFrom = []
        for Attribute in self.__dict__:
            if self.get(Attribute) and type(self.get(Attribute)) == list:
                DeleteFrom.append(Attribute)
                #print(Attribute, len(self.get(Attribute)) )     #################         #####################
        # Mark reflections for removal if they do not pass the filter
        RemoveID = set()
        for j, HKL in enumerate(self.HKL):
            for (i, P) in enumerate(Parameters):
                if not (LowLimit[i] <= self.get(P)[j] <= HighLimit[i]):
                    RemoveID.add(j) # mark reflection j for removal
        RemoveID = list(RemoveID)
        RemoveID.sort(reverse=True) # sort from highest ID to smaller                
        # Apply filter
        #print(len(self.ZoneID), "filter:", len(RemoveID)) #################         #####################
        for j in RemoveID:
            for List in DeleteFrom:
                #print(j, len(self.ZoneID), List)
                #print(List, j)
                self.get(List).pop(j)
        self.log("Removed "+str(len(RemoveID))+" reflections.")
        self.calc_r()
        self.Mother.status()


    def list_zones(self, event=None):
        if not self.loaded:
            self.log("\nREF file not loaded.")
            return False
        #>>>>>>> Block Zone# Robs wRobs Rall wRall Nobs Nall
        form = "{:>5d} {:>4d} {:8.2f} {:8.2f} {:8.2f} {:8.2f} {:4d} {:4d}\n"
        self.log("\n***** LIST ZONES FROM REF FILE *****\n")
        self.log("Block Zone     Robs    wRobs     Rall    wRall Nobs Nall\n")
        for i, block in enumerate(self.ZoneStats):
            BlockID = self.Blocks[i]
            for j in range(len(self.ZoneStats[i]["zone"])):
                self.log(form.format(BlockID, j+1, block["Robs"][j],
                                          block["wRobs"][j], block["Rall"][j], 
                                          block["wRall"][j], block["Nobs"][j], block["Nall"][j]))

    def calc_DF_distribution(self, weighted=True, event=None):
        if weighted:
            List = self.wDF
            Label = "weighted (Fo-Fc)"
        else:
            List = self.DF_over_sigma
            Label = "(Fo-Fc)/sigma"
        Mean, Sigma = drm.standard_uncertainty(List)
        
        Msg = "Mean " + Label + "{:8.4f}".format(Mean) + "   Sigma: " + "{:8.4f}".format(Sigma)
        print(Msg)
        self.log(Msg)


    def sort_reflections(self, event=None, sortby=""):
        """ Sort reflections according to chosen property, e.g. "g", "d2x", "RSg", "zone", "Fo", "Fc", "sigma"
        Sorting by "i" resets initial order
        """
        while sortby not in self.Reflections[0]:
            sortby = input("Sort reflections by e.g. (zone, Fo, g, d2x, RSg, zone, DSg): ")
            if sortby not in self.Reflections[0]:
                print("This key does not exist.")
            
        for BlockI, Block in enumerate(self.Reflections):
            # Block["Fc"] = [firstFc, secondFc, thirdFc, ..., ithFc]
            OldOrder = [ (i, value) for (i, value) in enumerate(Block[sortby]) ]
            OldOrder.sort(key=lambda x: x[1])
            NewOrder = [ element[0] for element in OldOrder ]
            for label in self.Reflections[BlockI]: # loop through all all dictionary keys ("hkl", "Fo", etc...)
                print("Sorting ", label, " of Block", self.Blocks[BlockI])
                NewList = []
                for i in NewOrder:
                    NewList.append(self.Reflections[BlockI][label][i])
                self.Reflections[BlockI][label] = NewList # replace list with old order by new ordered list
        print("Finished sorting by ", sortby, ".")


    def log(self, addlog, end="\n"):
        self.Mother.log(entry=addlog, end=end)
        
    def __del__(self):
        self.Mother.log(entry="Destroyed Reflections object "+str(self.BlockID)+".")

###############################################################################
###############################################################################

###############################################################################
###############################################################################

def ref_import(parent, file=None):
    """ Read REF file, create object "reflectionsblock" for each block """
    if not file:
        RefFile = parent.get_jana_file_path("ref")
    else:
        RefFile = file
        
    if RefFile:
        with open(RefFile, "r") as fh:
            Lines = fh.readlines()
    else:
        print("FAILED reading ref file.")
        return {}
        
    # prepare variables used in loop reading lines
    Blocks = dict()
    Wavelength = dict()
    InstabilityFactor = 0.01
    RefinementBase = "F"
    BlockID = 1
    RadiationBlock = 0
    loadReflections = False
    readFoFc = False
    Section = "control data"
    
    for line in Lines:
        """ Loop through all lines. Three important multi-line blocks:
            1) List of reflections 2) R factors of individual zones 3) Parameter changes
            No implemented yet: 3) Parameter changes
            NOT VALID YET FOR REFINEMENT ON F^2 ! ! !
        """
        # 1) Reflections
        #print(line[:-1])
        if readFoFc and len(line) >= 120 and line[17] == "." and line[27] == ".": # line length should be exactly 120
            Blocks[BlockID].ZoneID.append(int(line[116:120]))
            
            h = int(line[0:4])
            k = int(line[4:8])
            l = int(line[8:12])
            Blocks[BlockID].h.append(h)
            Blocks[BlockID].k.append(k)
            Blocks[BlockID].l.append(l)
            Blocks[BlockID].HKL.append( (h,k,l) ) # tuple (h,k,l)
            
            Fo = float(line[12:22])
            Fc = float(line[22:32])
            Fsigma = float(line[62:72])
            Fweight = 1/float(line[72:82])
            wDF = Fweight*(Fo-Fc)
            """
            WeightX = float(line[72:82])
            if RefinementBase == "F":
                try:
                    Fsigma = sqrt(WeightX**2 - (InstabilityFactor*Fo)**2)
                except:
                    print(line)
            else:
                Fsigma = sqrt( WeightX**2/(2*Fo)**2 - (InstabilityFactor*Fo*Fo)**2)
        	""" #                 
            Blocks[BlockID].Fo.append(Fo)
            Blocks[BlockID].Fc.append(Fc)
            Blocks[BlockID].Fsigma.append(Fsigma)
            Blocks[BlockID].Fweight.append(Fweight)
            Blocks[BlockID].Fo_over_sigma.append(Fo/Fsigma)
            Blocks[BlockID].DF_over_sigma.append((Fo-Fc)/Fsigma)
            Blocks[BlockID].wDF.append(wDF)
            Blocks[BlockID].DeltaF.append(Fo-Fc)
            
            ObsFlag = 0 if line[99] == "*" else 1
            Blocks[BlockID].ObsFlag.append(ObsFlag)            
            Blocks[BlockID].nref.append(int(line[92:99])) # each reflection is given an ID by JANA, first column in M95 file

        # Trigger lines
        elif line.startswith("* "):
            Section = line.replace("*","").strip()
            if "Fo/Fc list after last cycle" in Section:
                BlockID = int(line[37:].split()[0]) if "Block" in Section else 1
                Blocks[BlockID] = reflectionsblock(parent) # init object
                Blocks[BlockID].BlockID = BlockID
                Blocks[BlockID].Origin = RefFile
                readFoFc = True
            elif Section == "Fo/Fc list of worst fitted reflections":
                readFoFc = False
                """            
                elif line.startswith("* Fo/Fc list of worst fitted reflections *"):
                    readFoFc = False
                elif loadReflections and line.startswith("* Fo/Fc list after last cycle *"):
                    BlockID = 1
                    Blocks[BlockID] = reflectionsblock(parent) # init object
                    Blocks[BlockID].BlockID = BlockID
                    Blocks[BlockID].Origin = RefFile
                    readFoFc = True
                elif loadReflections and line.startswith("* Fo/Fc list after last cycle - Block"):
                    BlockID = int(line[37:].split()[0])
                    Blocks[BlockID] = reflectionsblock(parent) # init object
                    Blocks[BlockID].BlockID = BlockID
                    readFoFc = True
                """
        # Other parameters/lines of interest
        elif Section == "Fo/Fc list of worst fitted reflections" and (line.startswith("|") or line.startswith("---")):
            parent.log(entry=line[:-1]) # Print R factors = last screen information window
        elif line.startswith("Block") and Section == "Radiation":
            RadiationBlock = int(line.split("Block")[1])          
        elif line.startswith("Wave length:"): # SIC (OED suggests wavelength)
            Wavelength[RadiationBlock] = float(line[14:21]) # in Angstrom
        elif line.startswith("=>"):
            cmd = line.split("=")[1][1:-1]
            if "print 2" in cmd or "print 3" in cmd:
                loadReflections = True
            if "twdetail 1" in cmd:
                loadReflections = False # reading twin detail Fo/Fc list not implemented yet ...
            if "fsquare 1" in cmd:
                parent.log(entry="Refinement on F^2!")
                RefinementBase = "F2"
        elif "coefficient of unstability" in line: #s.i.c.
            InstabilityFactor = float(line.split()[-1])
            
    if not loadReflections:
        # Last Refinement summary (R factors etc) is logged anyway.
        parent.log(entry="REF file only contains non-matching reflections.")
        return False
    for BlockID in Wavelength:
        if BlockID in Blocks:
            Blocks[BlockID].Wavelength = Wavelength[BlockID]
    return Blocks # returns a dictionary with key = BlockID and value = "ReflectionsBlock" object



def m83_import(parent, file=None):
    # FORMAT:
    # kinematical: M80factor = sqrt(1/scale)
    #   h   k   l   Ic             Io             Isigma      obs   Twin  w(Fo-Fc) s*sqrt(Ic) s*sqrt(Io) 1/weight M80factor   sqrt(A^2+B^2) A         B 
    #   0   1   0   0.259254E+02   0.289628E+02   0.466400E+00 o    1     4.197     21.00     19.87      0.27    0.65690E-01      5.09     -5.09      0.00
    # dynamical:
    #   h   k   l   Ic             Io             Isigma      obs   Twin  w(Fo-Fc) s*sqrt(Ic) s*sqrt(Io) 1/weight M80factor       0         0         0       Zone%Block
    #   2   2  -7   0.112630E+03   0.299800E+03   0.203200E+03 <    1     1.142     17.31     10.61      5.87    0.20610E-01      0.00      0.00      0.00     1
    # Jana2020
    #  -6   6  -1   0.667110E+02   0.125900E+03   0.163400E+03 <    1     0.419     11.22      8.17      7.28    0.10924E+01      0.00      0.00      0.00              0     1
    #  -5   5  -6   0.262570E+04  -0.455800E+03   0.241000E+03 <    1    -0.660      0.00     51.24     77.62    0.54467E-01      0.00      0.00      0.00              0 1%1    
    if not file:
        M83File = parent.get_jana_file_path("m83")
    else:
        M83File = file
        
    if M83File:
        with open(M83File, "r") as fh:
            Lines = fh.readlines()
    else:
        print("FAILED reading M83 file.")
        return {}
    # Init object for block 1
    Blocks = dict()
    BlockID = 1
    #Blocks[1].BlockID = 1
    
    for line in Lines:
        # 1) Reflections
        #if 152 < len(line) < 157: # dynamic, ZoneID at the end
        if len(line) in (150,165): # kinematical refinement
            Zone = False
            BlockID = 1
        elif len(line) in (154, 155, 156,157, 169, 171,172,173,174): # dynamical refinement
            Zone = line.split()[-1]
            if "%" in Zone:
                Zone, Block = Zone.split("%")
                BlockID = int(Block)
        else: # neglect empty line at the end and Refblock
            continue
        # Define block
        if BlockID not in Blocks:
            Blocks[BlockID] = reflectionsblock(parent) # create new reflection block
            Blocks[BlockID].BlockID = BlockID
            Blocks[BlockID].Origin = M83File
        if Zone:
            ZoneID = int(Zone)
            Blocks[BlockID].ZoneID.append(ZoneID)
        
        h = int(line[0:4])
        k = int(line[4:8])
        l = int(line[8:12])           
        Blocks[BlockID].h.append(h)
        Blocks[BlockID].k.append(k)
        Blocks[BlockID].l.append(l)
        Blocks[BlockID].HKL.append( (h,k,l) ) # tuple (h,k,l)
        
        Ic = float(line[14:27]) # Ic column is before Io column
        Io = float(line[29:42]) # MINUS sign not read until 02.11.2020
        Isigma = float(line[45:57])
        
        wDF = float(line[64:74])
        Fo = float(line[76:84])
        Fc = float(line[86:94])        
        Fweight = 1/float(line[96:104])
        #Fsigma = Fo/(2*Io)*Isigma if Io != 0 else Isigma # Fsigma = s/(2*sqrt(Io)) * Isigma; s = Fo/sqrt(Io) = scale
        Fsigma = Isigma/(2*Fo) if Io >= 0.01*Isigma else 5*sqrt(Isigma)
        
        M80Factor = float(line[104:119]) # only 5 decimal places ! (why?)
        #Fo, Fc, sigmaF = drm.F_from_I(Io, Ic, Isigma)
        Blocks[BlockID].Io.append(Io)
        Blocks[BlockID].Ic.append(Ic)
        Blocks[BlockID].DeltaI.append(Io-Ic)
        Blocks[BlockID].Isigma.append(Isigma)
        Blocks[BlockID].Fo.append(Fo)
        Blocks[BlockID].Fc.append(Fc)
        Blocks[BlockID].Fsigma.append(Fsigma)
        Blocks[BlockID].wDF.append(wDF)
        Blocks[BlockID].DeltaF.append(Fo-Fc)
        Blocks[BlockID].Fweight.append(Fweight)        
        Blocks[BlockID].M80Factor.append(M80Factor)
        
        if Isigma != 0 != Fsigma:
            Blocks[BlockID].Io_over_sigma.append(Io/Isigma)
            Blocks[BlockID].DI_over_sigma.append((Io-Ic)/Isigma)
            Blocks[BlockID].Fo_over_sigma.append(Fo/Fsigma)
            Blocks[BlockID].DF_over_sigma.append((Fo-Fc)/Fsigma)
        else:
            Blocks[BlockID].Io_over_sigma.append(float("NaN"))
            Blocks[BlockID].DI_over_sigma.append(float("NaN"))
            Blocks[BlockID].Fo_over_sigma.append(float("NaN"))
        
        ObsFlag = 1 if line[58] == "o" else 0
        Blocks[BlockID].ObsFlag.append(ObsFlag)
    return Blocks # returns a dictionary with key = BlockID and value = "ReflectionsBlock" object


def cif_pets_import_reflections(parent, file=None):
    """ Import reflections from dyn.cif_pets file """
    if not file:
        print("No dyn.cif_pets file provided.")
        return False
    CifPetsFile = file
    fh = open(CifPetsFile, "r")
    
    # Jump to first _refln_* line
    while True:
        line = fh.readline()
        if line.startswith("_refln"):
            break
    # Read _refln_* column labels
    # Current line is first line after last zone
    ReflectionColumns = []
    while True:
        if line.startswith("_refln_"):
            ReflectionColumns.append(line.strip())
        elif len(line.split()) > 3:
            break
        line = fh.readline()
    # Read reflections
    Reflections = []
    while True:
        Columns = line.split()
        if len(Columns) == len(ReflectionColumns):
            Reflections.append(Columns)
        else:       # There may not be a blank line after _loop until the end of the block. 
            if "*****" in line:
                print("FAILED import reflection:", line)
            else:
                break   # Breaks automatically at first line with not enough columns, including "loop_" or empty lines
        line = fh.readline()
    fh.close()
    # FINISHED reading file and extracting data
    
    # CREATE ZONE OBJECT
    ColumnZoneID = ReflectionColumns.index("_refln_zone_axis_id")
    ColumnH = ReflectionColumns.index("_refln_index_h")
    ColumnK = ReflectionColumns.index("_refln_index_k")
    ColumnL = ReflectionColumns.index("_refln_index_l")
    ColumnIo = ReflectionColumns.index("_refln_intensity_meas")
    ColumnIsigma = ReflectionColumns.index("_refln_intensity_sigma")
    
    Block = reflectionsblock(parent)
    Block.Origin = CifPetsFile
    Block.BlockID = 1
    for Line in Reflections:
        Block.ZoneID.append(int(Line[ColumnZoneID]))
        Block.h.append(int(Line[ColumnH]))
        Block.k.append(int(Line[ColumnK]))
        Block.l.append(int(Line[ColumnL]))
        Block.HKL.append( ( int(Line[ColumnH]),int(Line[ColumnK]),int(Line[ColumnL]) ) )
        Io = float(Line[ColumnIo])
        Isigma = float(Line[ColumnIsigma])
        Block.Io.append(Io)
        Block.Isigma.append(Isigma)
        if Isigma > 0:
            Block.Io_over_sigma.append( Io/Isigma )
        else:
            Block.Io_over_sigma.append( NaN )
            
    return {1: Block}


def m80_import_reflections(parent, file=None):
    """ Import reflections from M80 file
    Reflections are not related to a frame any more and thus reading of zone parameters is irrelevant.
    The information may be useful for evaluation of Fourier maps.
    
    The M80 file is created by the refinement routine of JANA2006 during the last cycle. It is required to calculate Fourier and Patterson maps.
    The columns of the M80 file contain the following information:
    h, k, l, (twin domain?), Fobs, Fobs, Fcalc, Re(Fcalc), Im(Fcalc), ?, ?, ?, ?, ?, ?, sigma(Fobs), sigma(Fobs)
    """
    M80File = file if file else parent.get_jana_file_path("m80")
    if M80File:
        with open(M80File, "r") as fh:
            Lines = fh.readlines()
    else:
        print("FAILED reading M80 file.")
        return False
    
    Blocks = dict()
    BlockID = 0
    CounterBegin = 0
    Counter000 = 0
    for line in Lines:
        if len(line) > 170: # standard line h k l Fo Fo Fc A B . . . . . . FoFc_factor sigma sigma:
            h,k,l = int(line[0:4]), int(line[4:8]), int(line[8:12])
            if h == k == l == 0:
                Counter000 += 1
                if Counter000 > CounterBegin:
                    BlockID += 1
                    Blocks[BlockID] = reflectionsblock(parent)
                    Blocks[BlockID].Origin = M80File
                    Blocks[BlockID].BlockID = BlockID
            Blocks[BlockID].h.append(h)
            Blocks[BlockID].k.append(k)
            Blocks[BlockID].l.append(l)
            Blocks[BlockID].HKL.append( (h,k,l) )
            Fo = float(line[16:28])
            Fc = float(line[40:52])
            Fsigma = float(line[148:160])
            Blocks[BlockID].Fo.append(Fo)
            Blocks[BlockID].Fc.append(Fc)
            Blocks[BlockID].Fsigma.append(Fsigma)
            DF_over_sigma = (Fo-Fc)/Fsigma if Fsigma > 0 else NaN
            Blocks[BlockID].DeltaF.append(Fo-Fc)            
            Blocks[BlockID].DF_over_sigma.append(DF_over_sigma)            
            Blocks[BlockID].M80Line.append(line)
        elif "begin" in line:
            BlockID = int(line.split()[0][5:])
            CounterBegin += 1
            Blocks[BlockID] = reflectionsblock(parent)
            Blocks[BlockID].Origin = M80File
            Blocks[BlockID].BlockID = BlockID
    return Blocks

def rprof_import_reflections(parent, file=None):
    """ Import reflections from PETS reflection profile file
    The *rprofall or *rprofstr file is created by PETS during data integration.
    In former PETS versions, this file was called reflprofiles_all.dat or reflprofiles_strong.dat.
    The columns of the files contain the following information:
    Listed in numbered batches
    h, k, l, g, Sg, RSg, I_obs, I_sigma, Camel, FrameID
    """
    
    ReflFile = file if file else parent.get_jana_file_path("rprofall")
    if ReflFile:
        with open(ReflFile, "r") as fh:
            Lines = fh.readlines()
    else:
        print("FAILED reading reflection profile file.")
        return False
    
    Blocks = dict()
    BlockID = 1
    Blocks[BlockID] = reflectionsblock(parent)
    Blocks[BlockID].Origin = ReflFile
    Blocks[BlockID].BlockID = BlockID
    
    for line in Lines:
        if len(line) < 10: # standard line
            continue
        
        h,k,l = int(line[0:4]), int(line[4:8]), int(line[8:12])
        g = float(line[12:26]) 
        Sg = float(line[26:40])
        RSg = float(line[40:54])
        Io = float(line[54:68])
        Isigma = float(line[68:82])
        if Isigma == 0:
            Isigma = float("NaN")
        ZoneID = int(line[96:100])
        
        Blocks[BlockID].h.append(h)
        Blocks[BlockID].k.append(k)
        Blocks[BlockID].l.append(l)
        Blocks[BlockID].HKL.append( (h,k,l) )
        Blocks[BlockID].g.append(g)
        Blocks[BlockID].Sg.append(Sg)
        Blocks[BlockID].RSg.append(RSg)
        Blocks[BlockID].Io.append(Io)
        Blocks[BlockID].Io_over_sigma.append(Io/Isigma)
        Blocks[BlockID].Isigma.append(Isigma)
        Blocks[BlockID].ZoneID.append(ZoneID)
        Blocks[BlockID].OnNframes.append(1)
    for i in range(len(Blocks[BlockID].HKL)):
        Blocks[BlockID].OnNframes[i] = Blocks[BlockID].HKL.count(Blocks[BlockID].HKL[i])
    return Blocks
    
def dyntmp_import_reflections(parent, file=None):
    """ Import reflections from PETS dyntmp file
    The *dyntmp file is created by PETS during data integration.
    h k l intensity uncertainty posX posY posX posY FrameID Zero |g| Sg |RSg| DSg(?)
    
    Write 2 Blocks: 
    Block 1 = raw import
    Block 2 = Iobs summed up, sigma sqrt(sum of squares)
    """
    
    DyntmpFile = file if file else parent.get_jana_file_path("dyntmp")
    if DyntmpFile:
        with open(DyntmpFile, "r") as fh:
            Lines = fh.readlines()
    else:
        print("FAILED reading reflection profile file.")
        return False
    
    Blocks = dict()
    for BlockID in (1,2):
        Blocks[BlockID] = reflectionsblock(parent)
        Blocks[BlockID].Origin = DyntmpFile
        Blocks[BlockID].BlockID = BlockID
    BlockID = 1
    for line in Lines:       
        h,k,l = int(line[0:4]), int(line[4:8]), int(line[8:12])
        g = float(line[94:104]) 
        Sg = float(line[104:114])
        RSg = float(line[114:124])
        Io = float(line[12:28])
        Isigma = float(line[28:44])
        if Isigma == 0:
            Isigma = float("NaN")
        ZoneID = int(line[84:89])
        
        Blocks[BlockID].h.append(h)
        Blocks[BlockID].k.append(k)
        Blocks[BlockID].l.append(l)
        Blocks[BlockID].HKL.append( (h,k,l) )
        Blocks[BlockID].g.append(g)
        Blocks[BlockID].Sg.append(Sg)
        Blocks[BlockID].RSg.append(RSg)
        Blocks[BlockID].Io.append(Io)
        Blocks[BlockID].Io_over_sigma.append(Io/Isigma)
        Blocks[BlockID].Isigma.append(Isigma)
        Blocks[BlockID].ZoneID.append(ZoneID)
        #Blocks[BlockID].OnNframes.append(1)
    BlockID = 2    
    for hkl in set(Blocks[1].HKL):
        #hkl = Blocks[1].HKL[i]
        ii = [ index for index in range(len(Blocks[1].HKL)) if Blocks[1].HKL[index] == hkl ]
        i0 = ii[0]
        h,k,l = hkl
        Io = sum([Blocks[1].Io[i] for i in ii])
        Isigma = sqrt( sum([ Blocks[1].Isigma[i]**2 for i in ii]) )
        Blocks[BlockID].h.append(h)
        Blocks[BlockID].k.append(k)
        Blocks[BlockID].l.append(l)
        Blocks[BlockID].HKL.append( hkl )
        Blocks[BlockID].OnNframes.append( Blocks[1].HKL.count(hkl) )
        Blocks[BlockID].g.append( Blocks[1].g[i0])
        Blocks[BlockID].Io.append( Io )
        Blocks[BlockID].Isigma.append( Isigma )
        Blocks[BlockID].Io_over_sigma.append(Io/Isigma)
    return Blocks    
# T E S T:
#test = ref_import(None, file="D:\\OneDrive\\ED_Data\\NEW_DYNGO\\Mordenite_s3m6\\n_s3m6.ref")
#print(len(test[1].Fo))
    
# T E S T:
#test83 = m83_import(None, file="D:\\OneDrive\\ED_Data\\NEW_DYNGO\\Mordenite_s3m6\\n_s3m6.m83")
#test83 = m83_import(None, file="D:\\OneDrive\\SCIENCE\\2020-03_ConTilt\\Glycine-beta\\5+2JANA\\4-select.m83")
#print(len(test83[1].Io))

# T E S T:
#test = cif_pets_import_reflections(None, file="D:\\OneDrive\\ED_Data\\2019-09_Stockholm\\Mordenite\\s3m6_cont_FO\\s3m6_dyn.cif_pets")
#print(len(test[999].Io))
    
# T E S T:
#test = m80_import_reflections(None, #ile="D:\\OneDrive\\Science\\2019-11_WORKSHOP\\TestFoFc\\test_rescale2Fcalc.m80")
#print(len(test[1].Fo))
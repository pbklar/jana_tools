"""
The files should also be callable WITHOUT the GUI.
"""
#import os
import sys
import wx
from os.path import isdir
from datetime import datetime
#import wx.lib.buttons as buttons
#import filesfolders as ff
#import GUIpanels

import dynrockcomponents as drc
import GUIcomponents as GUIc

import GUIplot


def start_dynrock(application):
    '''Start up the GUI: This function is called from the MAIN python file.'''
    application.main = MotherFrame(parent=None) # main wx.Frame
    application.SetTopWindow(application.main)
    application.GetTopWindow().Show(True)

    
class MotherFrame(wx.Frame):
    ''' This is the core of the program.
    + all 'global' variables are defined in this class.
    + other modules and functions are called from this class
    + the main menu is defined here, but menus are initialized elsewhere
    + panels are implemented in this frame, but each defined in its own class
    
    INITIALIZATION:
    + _init_panels
      + initialize FILE menu
    + _init_vars
    '''    
    def __init__(self, parent):
        #self.Image = wx.Image("paul.ico", wx.BITMAP_TYPE_ICO)
        wx.Frame.__init__(self, name="DynRock_MotherFrame", parent=parent, 
                          size=(1000,800), style=wx.DEFAULT_FRAME_STYLE, 
                          title="DynRock")
        self.Bind(wx.EVT_CLOSE, self.ExitMain)
        drc.init_variables(self)
        self.Controller = "GUI"
        self.NotebookZoneTabs = 1
        self.NotebookReflectionTabs = 1
        self.NotebookProfileTabs = 1
        
        self.MotherSizer = wx.BoxSizer(orient=wx.VERTICAL) # control unit that will arrange its elements
        self.MotherPanel = wx.Panel(self) # main panel that will be the parent of the elements #
        
        self.Notebook = wx.Notebook(self.MotherPanel)
        self.TabStatus = GUIc.status_panel(parent=self.Notebook, title="DynRock options")
        self.Tabs = []
        self.Tabs.append(self.TabStatus)
        self.Tabs.append(GUIplot.plotzone(parent=self.Notebook, title="NotebookTabZone1"))
        self.Tabs.append(GUIplot.plotreflection(parent=self.Notebook, title="NotebookTabReflection1"))
        self.Tabs.append(GUIplot.plotprofile(parent=self.Notebook, title="NotebookTabProfile1"))
        
        self.Notebook.AddPage(self.TabStatus, "DynRock")
        self.Notebook.InsertPage(index=1, page=self.Tabs[1], text="--- Zone")
        self.Notebook.InsertPage(index=2, page=self.Tabs[2], text="::: Reflections")
        self.Notebook.InsertPage(index=3, page=self.Tabs[3], text="_^_ Profile")
        self.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, self.on_tab_change)
        
        self.MotherSizer.Add(self.Notebook, 1, flag=wx.EXPAND)
        self.MotherPanel.SetSizer(self.MotherSizer)
        self.quick_start()
        
        GUIc.menubar(self)
        #print(self.TabPlotZone.__dict__)
        #GUIc.GUI_wizard(self)
        
    def quick_start(self):
        # Check if DynRock was started with arguments allowing to directly load input files.
        Arguments = sys.argv
        #Arguments.append("D:\\OneDrive\\ED_Data\\NEW_DYNGO\\Mordenite_s3m6\\n_s3m6.m40")
        if len(Arguments) > 1: # paths or files were provided
            for A in Arguments:
                if A[-3:] in {"m40","m42","m50","m80","m83","m90","m95","ref"}:
                    drc.init_jana_job(self, file=A)
                    break
                #elif A.endswith("m80"):
                #    drc.load_m80_file(self, file=A)
                #    break
                elif A.endswith("cif_pets"):
                    drc.init_cif_pets_job(self, file=A)
                    break
                elif A.endswith("rprofall") or A.endswith("rprofstr") or A.endswith("reflprofiles_all.dat") or A.endswith("reflprofiles_strong.dat"):
                    drc.init_reflprofiles_job(self, file=A)
                    break
                elif A.endswith("dyntmp"):
                    drc.init_dyntmp_job(self, file=A)
                    break                    
                elif A.endswith("ptsopt"):
                    drc.init_ptsopt_job(self, file=A)
                    break
                elif isdir(A):
                    drc.init_jana_job(self, file=A)
                    break
                
    def get_jana_file_path(self, ext):
        return drc.get_jana_file_path(self, ext=ext)                
    
    # S T A T U S
    def status(self, event=None):
        self.status_zones()
        self.status_reflections()
           
    def status_zones(self):
        self.TabStatus.ZonesStatus.SetValue(drc.status_zones(self))
    
    def status_reflections(self):
        self.TabStatus.ReflectionsStatus.SetValue(drc.status_reflections(self))        
        
    
    # D I A L O G
    def file_dialog(self, event=None, directory=None, extension=None):
        return GUIc.GUI_file_dialog(directory=directory, extension=extension)
    
    def input_dialog(self, event=None, request="Enter 3 integers:", default="", title="User input request", parameters=None):
        """ General dialog with one return value. If three inputs are required,
        then values should be separated by blanks: x y z
        """
        if parameters:
            request += "\n(enter exactly "+str(parameters)+" value"
            if parameters > 1:
                request += "s separated by blank spaces"
            request += ")"
        Dialog = wx.TextEntryDialog(parent=None, message=request, caption=title,
                                    value=default, style=wx.OK|wx.CANCEL)
        if Dialog.ShowModal() == wx.ID_OK:
            Answer = Dialog.GetValue()
            Dialog.Destroy()            
            if parameters and len(Answer.split()) != parameters:
                NewTitle = "Again: "+title 
                Answer = self.input_dialog(request=request, default=Answer, title=NewTitle, parameters=parameters)
            return Answer
        else:
            Dialog.Destroy()       


    def log(self, event=None, entry="", end="\n"):
        Time = datetime.now()
        Time = "{:02d}:{:02d}:{:02d} ".format(Time.hour, Time.minute, Time.second)
        if type(entry) is list:
            for item in entry:
                self.TabStatus.MainLog.AppendText(str(item))
            self.TabStatus.MainLog.AppendText(end)
        elif type(entry) is str or type(entry) is int or type(entry) is float:
            self.TabStatus.MainLog.AppendText(Time+str(entry)+end)
        
    # P L O T   TABs
    def add_zone_plot(self):
        NewIndex = 1 + self.NotebookZoneTabs
        NewTab = GUIplot.plotzone(parent=self.Notebook, title="NotebookZoneTab"+str(NewIndex))
        self.Notebook.InsertPage(index=NewIndex, page=NewTab, text="--- Zone "+str(self.NotebookZoneTabs+1))
        self.NotebookZoneTabs += 1
        self.Tabs.append(NewTab)
        NewTab.update_block_ids()
        return NewIndex
        
    def add_reflection_plot(self):
        NewIndex = 1 + self.NotebookZoneTabs + self.NotebookReflectionTabs
        NewTab = GUIplot.plotreflection(parent=self.Notebook, title="NotebookReflectionTab"+str(NewIndex))
        self.Notebook.InsertPage(index=NewIndex, page=NewTab, text="::: Reflections "+str(self.NotebookReflectionTabs+1))
        self.NotebookReflectionTabs += 1
        self.Tabs.append(NewTab)
        NewTab.update_block_ids()
        return NewIndex
        
    def add_profile_plot(self):
        NewIndex = 1 + self.NotebookZoneTabs + self.NotebookReflectionTabs + self.NotebookProfileTabs
        NewTab = GUIplot.plotprofile(parent=self.Notebook, title="NotebookReflectionTab"+str(NewIndex))
        self.Notebook.InsertPage(index=NewIndex, page=NewTab, text="_^_ Profile "+str(self.NotebookProfileTabs+1))
        self.NotebookProfileTabs += 1
        self.Tabs.append(NewTab)
        NewTab.update_block_ids()
        return NewIndex

    def on_tab_change(self, event=None):
        # Update BlockID dropdown menu
        TabID = self.Notebook.GetSelection()
        if TabID > 0:
            self.Tabs[TabID].update_block_ids()
        pass
        
    ############################################################################
    # EVENT FUNCTIONS                                 
    def OnStatus(self, event):
        print("* * * *") 
        """
        print("PETS status")
        if self.PetsLoaded:
            print(self.PetsFiles)
        else:
            print("... not loaded ...")
        """
        print("JANA status")
        if self.JanaLoaded:
            for key, value in self.JanaFiles.items():
                print(key, ":", value)
            for BlockID, Block in self.ZoneBlock.items():
                print("Block ", BlockID)
                for item in Block.__dict__:
                    List = Block.get(item)
                    if type(List) is list and len(list(filter(None, List))) > 0:
                        print(item, min(filter(None, List)), max(filter(None, List)))
        else:
            print("... not loaded ...")
        print("* * * *") 
        
    def OnAbout(self, event):
        print("This program was written by Paul.")        
    
    def OnExit(self, event):
        self.Close()
        #self.ExitMain()
        
    def ExitMain(self, event=None):
        sys.exit()
        
"""
self.MainTitle = wx.StaticText(self.MainPanel, label="Main panel")
self.MainTitle.SetFont(wx.Font(14, wx.SWISS, wx.NORMAL, wx.NORMAL))
"""        
###############################################################################
###############################################################################


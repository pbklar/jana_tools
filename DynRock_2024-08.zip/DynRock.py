#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
*DynRock*
=========
Initial program structure based on GSAS-II.
Establish a well structured program as a basis for future programs.
Copy structure from GSAS-II.
1. Create APP
2. Call main -> GUI + event loop
'''

try:
    import wx
    import GUI
    LoadGUI = True
except ModuleNotFoundError:
    LoadGUI = False
    import CMD
    print("GUI (graphical user interface) cannot be loaded because package 'wx' (wxpython) is required but not found.")
    print("Please install the wx package:")
    print("Using pip under windows: pip install -U wxPython")
    print("Anaconda environment: conda install -c anaconda wxpython # or install with Anaconda Navigator")
    print("General: check https://wxpython.org/pages/downloads/")
    
__version__ = "2022-08-09"

print("D y n R o c k\nversion", __version__)

if __name__ == "__main__":      # only start if this is the main python program and not called as a sub-routine
    if LoadGUI:
        WxApplication = wx.App(0)           # GUI framework        
        GUI.start_dynrock(WxApplication)    # call main() from mainGUI.py        
        WxApplication.MainLoop()
    else:
        CMD.start_dynrock()

"""
ROAD MAP:
+ merge frames: save location and file name of input file + "DynRock_merge"
+ merge frames dialogue with more than one input field
+ merge frames: allow classical (static merging of M frames in S steps)

+ optimize orientation by optimizing Sg ?

+ PLOT: allow to click on data points and provide more information:
    ZONE: ID alpha beta omega phi Robs Rall
    REFLECTION: h k l g  
    PROFILE: ZoneID Fo Io I_over_sigma

+ check PROFILE: mordenite: same reflection twice on one frame?!

+ Filter for PLOT PROFILE
+ "all" hkl of a certain frame

+ read pts_opt
+ allow opt_smooth
+ smoothing: allow to choose between moving average and linear polynomial fit
+ give summary of smoothing: average correction (absolute, alpha beta omega), MA how many frames
+ how many outliers? average outlier characteristics
+ automatically write file .pts with comment to mark outliers
+ automatically plot original alpha step, new alpha step


+ implement twinning = detect twinning domain, apply twin law

+ filtered output of selected block object attributes (shortcut button from PLOT reflections, PLOT profile)
 
+ compare orientation optimization and DYNGO orienation >> calc alpha' beta' omega'

+ reflection geometry output for a selected hkl
+ check that length of all attributes is identical (or 0), count Nones!

+ estimate completeness via intensity statistics, OM+UC, guessed rule categories (00l: l=Xn, hkl: h+l=2n)

+ how to calculate Fsigma if Io < 0
+ recheck differences between Fo from Io in Jana vs DynRock

+ calc 2Theta diffraction angle (calc hkl properties)

+ decrease dependency on Python console, prefer DynRock console.

+ make classes work also without the GUI

+ add file meta data from m95 (source file, file date(s))

+ M40 live mode: l99 containt Fo Fc of last cycle (?). Should be checked

  + Plot module:
      + color code function of parameter
    + plot sigma to Fo^^2
    + export for imageJ
    + export png via pyplot
"""
###############################################################################
"""
NAME SPACE (conventions used for DynRock program):

    this_is_a_function: e.g. calc_dynamical_intensity()
    thisisafunctionvariable, e.g. calc_dynamical_intensity(hkl, om, alpha)
    
    ThisIsAVariable: e.g. NumberOfReflections
    UPPERCASE for triplet variables of type tuple: HKL, XYZ, UVW, ABC
    Scientifically meaningful variables try to maintain uppercase and lowercase letters, e.g. RSg, g, Fobs, Falc
    
    gui_Element: variables containing GUI elements use a suffix gui_ (not strictly followed yet, 27.10.2019)
    
    "dictionarylabels" are usually lowercase except for scientific symbols, e.g. "RSg", "Fo"
    
    THIS_IS_A_CONSTANT: e.g. PI
    
    ThisIsAClass: e.g. M80Panel
    
    thisisapythonfile: I will not strictly follow this rule.
"""    
###############################################################################
"""
PYTHON COLLECTIONS:
  
() TUPLES: ordered, unchangeable, indexed. You cannot even ADD items
if there is only one item, an additional comma is needed oneitem = ("theItem",)
tuple3 = tuple1 + tuple2
UNCHANGEABLE

[] LISTS: ordered, changeable, duplicates allowed
list.append("newentry")
list.count("hi")
list.index("hi")
list.reverse()

{} SETS: unordered, unindexed, no duplicates
SETS if you loop through it "for x in set"
set.add("newentry")
MATH: union |   intersection &   difference -  symmetric difference ^
a = set("abcd")
b =   set("cdef")
a | b >> "abcdef"
a & b >> "cd"
a - b >> "ab"
a ^ b >> "abef"   

{} DICTIONARY: unordered, changeable, indexed
dict["newkey"] = "newvalue"
for key, value in NewDict.items()
for key in NewDict.keys()
for value in NewDict.values()

{key: value for key, value in zip(keylist, valuelist)}
dict([('key1', 'value1), ('key2', 'value2'), ... ])
"""
###############################################################################
"""
Recommendations according to PEP 8 style guide
b  B  lowercase  lowercase_w_underscore  UPPERCASE  UPPERCASE_W_UNDERSCORE  CapWords  mixedCase  prefix_SomeThing    

lowercase:
    + packages / modules+
    + functions, underscore allowed
    
CapWords:
    + class names
    + variables
    
UPPERCASE:
    + constants
"""
###############################################################################
"""
from timeit import default_timer as timer
start = timer()
# THE CODE
end = timer()
print(end - start)
"""
###############################################################################
"""
Other Python hints:
1. underscores _ are ignored for numbers to facilitate the input of long numbers:
    x = 4_123_23
    y = 3.141_592_653_589_793_238_462_643_383_279_502
2. NaN Not_a_number type:
    x = float("NaN")
3. Quick formatting:
    print(f'Pi is about {3.1415926535:.3f}.')
4. Formatting:
    "{a:bt}".format(*vars) a = variable_ID, b = length, t = type
    Float: {:.2f} {:8.2f}
    Int:   {:d} {:05d}
"""


"""
DONE:
    + Notebook tab positions
    + replace in GUIplot: BlockID text field by drop down menu
    + full output of block object attributes
    + implement float("NaN")
    
"""    
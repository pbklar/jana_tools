#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
JANA zone class
=====================
+ block zone
+ alpha beta omega phi
+ IED/PED
+ "refineables": scale, thickness, EDtheta, EDphi
+ OM
+ "m42 parameters": intsteps, threads, OM
                    csgmaxr, sgmax, sgmax(matrix), gmax,
+ properties: R factors, number of reflections
'''

# Example access: block[1] refers to object.
# block[1].Alpha[]
# could also be solved as dictionary, but as class we are "save for the future" (methods)
# and one is forced to keep to the class structure.

import dynrockmath as drm
import numpy as np
NaN = float("NaN")

class zoneblock:
    def __init__(self, parent):
        self.Mother = parent
        self.Origin = None # file from which zones were imported
        
        #self.Source = None # m42, cif_pets
        # m42 or cif_pets
        self.BlockID = None
        self.JanaBlockID = None
        self.Wavelength = None
        self.ZoneID = []
        self.Alpha = []
        self.Beta = []
        self.Omega = []
        self.Overlap = []
        self.AlphaStep = []
        self.BetaStep = []
        self.OmegaStep = []        
        self.Phi = []
        self.UVW = []
        #m42
        self.scale = [] # either from M42 or from cif_pets
        self.thickness = []
        self.InRefinement = [] # used for refinement
        self.EDphi = []
        self.EDtheta = []
        self.Geometry = None # "continuous" (IEDT), "precession" (PED), "static"
        self.OM = None        
        self.g_max = None
        self.RSg_max = None
        self.Sg_max = None
        self.Sg_max_matrix = None
        
        self.Robs = []
        self.Rall = []
        self.wRall = []
        self.Nobs = []
        self.Nall = []
        
        self.FrameFile = [] # frame file, usually as in PTS file
        self.AlphaCorrection = [] # ptsopt
        self.BetaCorrection = []
        self.OmegaCorrection = []
        self.Alpha0 = [] # from ptsopt, input Alpha which was optimized by PETS
        self.Beta0 = []
        self.Omega0 = []
        self.AlphaS = [] # Alpha after smoothing (moving average)
        self.BetaS =  []
        self.OmegaS = []
        self.AlphaStepS = [] # AlphaStep after smoothing
        self.BetaStepS =  []
        self.OmegaStepS = []
        self.MergedFrames = [] # how many frames were used to merge the new frame
        
        self.Diffrn_measurement_details = None
        
    
    def get(self, parameter, zoneid=0):
        if zoneid == 0:
            return getattr(self, parameter)
        else:
            if zoneid in self.ZoneID:
                if zoneid == self.ZoneID[zoneid-1]:
                    i = zoneid-1
                else:
                    i = self.ZoneID.index(zoneid)
                return getattr(self, parameter)[i]
            else:
                return False        
            
    def calc_steps(self):
        if not self.Phi:
            self.Phi = [ 0 for i in range(len(self.Alpha))]
        self.AlphaStep = []
        self.BetaStep = []
        self.OmegaStep = []
        self.Overlap = []
        if self.AlphaS: # smooth tilt steps
            self.AlphaStepS = []
            self.BetaStepS = []
            self.OmegaStepS = []
            
        for i, Alpha in enumerate(self.Alpha[:-1]):
            self.AlphaStep.append( self.Alpha[i+1] - Alpha )
            self.BetaStep.append( self.Beta[i+1] - self.Beta[i])
            self.Overlap.append( (self.Alpha[i]+self.Phi[i]) - (self.Alpha[i+1]-self.Phi[i+1]))
            if self.Omega:
                self.OmegaStep.append( self.Omega[i+1] - self.Omega[i])
            if self.AlphaS:
                self.AlphaStepS.append( self.AlphaS[i+1] - self.AlphaS[i] )
                self.BetaStepS.append( self.BetaS[i+1] - self.BetaS[i] )
                self.OmegaStepS.append( self.OmegaS[i+1] - self.OmegaS[i] )
        self.AlphaStep.append(0) # Alpha step of the last frame
        self.BetaStep.append(0)
        if self.Omega:
            self.OmegaStep.append(0)
        self.Overlap.append(0)
        if self.AlphaS:
            self.AlphaStepS.append(0)
            self.BetaStepS.append(0)
            self.OmegaStepS.append(0)
        
    def set_precession_geometry(self):
        self.Geometry = "precession"
        
    def set_continuous_geometry(self):
        self.Geometry = "continuous"        
        
    def apply_OO(self):
        """ Update alpha beta omega from EDphi and EDtheta """
        pass
                        
    def set_wavelength(self):
        """ Get the wavelength from REF, M90 or M95 """
        if self.Wavelength:
            return False
        if self.BlockID in self.Mother.ReflectionBlock:
            self.Wavelength = self.Mother.ReflectionBlock[self.BlockID].Wavelength
            #print("REF", self.Wavelength)
        if not self.Wavelength:
            self.Wavelength = m90_wavelength(self.Mother, self.JanaBlockID)
            #print("M90", self.Wavelength)
        if not self.Wavelength:
            self.Wavelength = m95_wavelength(self.Mother, self.JanaBlockID)
            #print("M95", self.Wavelength)
        #if not self.Wavelength:
        #    self.Wavelength = float(self.Mother.input_dialog(request="Enter the wavelength (0.0251 for 200 kV, 0.0335 for 120 kV):", default="0.0251", title="Wavelength", parameters=1))
    
    def smooth_steps(self):
        """ Smooth alpha beta and omega steps.
        Write new parameters into self.AlphaS / BetaS / OmegaS """
        if not self.AlphaStep:
            self.calc_steps()
        # Identify outliers:
        Alpha = list(self.Alpha) # list() necessary to make a new list, NOT a pointer
        self.AlphaS = Alpha
        self.AlphaStepS = list(self.AlphaStep)
        Beta = list(self.Beta)
        self.BetaS = Beta
        self.BetaStepS = list(self.BetaStep)
        Omega = list(self.Omega)
        self.OmegaS = Omega
        self.OmegaStepS = list(self.OmegaStep)
        AvgAlphaStep, AlphaStepSU = drm.standard_uncertainty(self.AlphaStep)
        AvgBetaStep, BetaStepSU = drm.standard_uncertainty(self.BetaStep)
        AvgOmegaStep, OmegaStepSU = drm.standard_uncertainty(self.OmegaStep)
        AlphaStepLimit = abs(AvgAlphaStep + 3*AlphaStepSU)
        BetaStepLimit = abs(AvgBetaStep + 3*BetaStepSU)
        OmegaStepLimit = abs(AvgOmegaStep + 3*OmegaStepSU)
        
        self.log(f"Average AlphaStep: {AvgAlphaStep:5.2f}({AlphaStepSU:.2f}) Outlier if > {AlphaStepLimit:.2f}")
        self.log(f"Average BetaStep:  {AvgBetaStep:5.2f}({BetaStepSU:.2f}) Outlier if > {BetaStepLimit:.2f}")
        self.log(f"Average OmegaStep: {AvgOmegaStep:5.2f}({OmegaStepSU:.2f}) Outlier if > {OmegaStepLimit:.2f}")
        
        MAN = int( self.Mother.input_dialog(request="Moving average of how many frames?", default="5", title="Moving average", parameters=1) )
        #MAN = 5
        Nexts = int(MAN/2)
        LastI = len(self.Alpha)-1
        
        # Determine and list outliers
        self.log("ZoneID Alpha AlphaStep Beta BetaStep Omega OmegaStep FrameFile")
        Outliers = list()
        OutliersLeft = list()
        OutliersRight = list()
        for i, AlphaStep in enumerate(self.AlphaStep):
            if ( i in (1,0) or i in (LastI-1, LastI) or # first and last frames will always be smoothed
              abs(AlphaStep) > AlphaStepLimit or
              abs(self.BetaStep[i]) > BetaStepLimit or
              abs(self.OmegaStep[i]) > OmegaStepLimit ):
                if i < Nexts:
                    OutliersLeft.append(i)
                elif i > LastI-Nexts:
                    OutliersRight.append(i)
                else:
                    Outliers.append(i)
                self.log(f"{self.ZoneID[i]:6d}   {self.Alpha[i]:6.2f} {AlphaStep:6.2f}  {self.Beta[i]:6.2f} {self.BetaStep[i]:5.2f}   {self.Omega[i]:5.2f} {self.OmegaStep[i]:5.2f}    {self.FrameFile[i]}")
        First = max(OutliersLeft)
        Last = min(OutliersRight)
    
        # case 1: frame is somewhere in the middle, take the mean    
        # Loop through all frames that can be calculated by standard mean averaging
        PtsForm ="{} {:8.3f} {:8.3f} {:8.3f}\n"
        PtsList = "\n"
        for i in range(LastI+1): # i must start at 0!
            if i <= First or i >= Last:
                continue
            UseFrames = []
            if i not in Outliers:
                UseFrames.append(i)
            j = 1
            while len(UseFrames) < MAN and j < 2*MAN: # add frames if their symmetric partner is not an outlier
                if i+j not in Outliers and i-j not in Outliers and i+j < LastI and i-j > 1:
                    UseFrames.append(i-j)
                    UseFrames.append(i+j)
                j += 1
            if len(UseFrames) <= 1: # do not use moving average, but extrapolation
                if i < LastI/2:
                    OutliersLeft.insert(0,i)
                else:
                    OutliersRight.insert(0,i)                
                continue
            self.AlphaS[i] = sum([Alpha[k] for k in UseFrames])/len(UseFrames)
            self.BetaS[i] = sum([Beta[k] for k in UseFrames])/len(UseFrames)            
            self.OmegaS[i] = sum([Omega[k] for k in UseFrames])/len(UseFrames)
            self.AlphaStepS[i-1] = self.AlphaS[i] - self.AlphaS[i-1]
            self.BetaStepS[i-1] = self.BetaS[i] - self.BetaS[i-1]
            self.OmegaStepS[i-1] = self.OmegaS[i] - self.OmegaS[i-1]
        # Remaining frames
        # case 2: frame is at the beginning or end, use extrapolation
        for i in OutliersLeft: # extrapolate from the right
            Neighbor = 1
            while i+Neighbor in OutliersLeft:
                Neighbor += 1
            self.AlphaS[i] = self.AlphaS[i+Neighbor] - Neighbor*AvgAlphaStep
            self.BetaS[i] = self.BetaS[i+Neighbor] - Neighbor*AvgBetaStep
            self.OmegaS[i] = self.OmegaS[i+Neighbor] - Neighbor*AvgOmegaStep
        for i in OutliersRight:
            Neighbor = 1
            while i-Neighbor in OutliersRight:
                Neighbor += 1
            self.AlphaS[i] = self.AlphaS[i-Neighbor] + Neighbor*AvgAlphaStep
            self.BetaS[i] = self.BetaS[i-Neighbor] + Neighbor*AvgBetaStep
            self.OmegaS[i] = self.OmegaS[i-Neighbor] + Neighbor*AvgOmegaStep

        # Print new frame list
        PtsList = "\n"
        for i in range(LastI+1):
            PtsList += PtsForm.format(self.FrameFile[i], self.AlphaS[i], self.BetaS[i], self.OmegaS[i])
        self.log(PtsList)
        self.calc_steps()
        return True        

    def log(self, addlog, end="\n"):
        self.Mother.log(entry=addlog, end=end)
        #print(addlog)
        
    def __del__(self):
        print("Destroyed Zone object "+str(self.BlockID)+".")
        
### # # # #  # ### # # # #  # ### # # # #  # ### # # # #  # ### # # # #  # ####        
### # # # #  # ### # # # #  # ### # # # #  # ### # # # #  # ### # # # #  # ####

def read_m42(file, read_frames=True):
    ''' updated 13 August 2024
    read (almost) all parameters from M42 file.
    
    read_frames: True = read complete M42 file
                 False = only read the configuration block at the very top of the M42 file
                 
    '''
    
    with open(file, 'r') as fh:
        Lines = fh.readlines()    

    end_config_line = Lines.index('end\n')
    N_blocks = (end_config_line-2) // 7

    m42 = dict()
    m42["File"]    = file
    m42["commands"] = Lines[0].strip()
    m42["dynamical"] = True if Lines[1][8] == '1' else False       # calcdyn 1
    m42["scale_to_Fcalc"] = True if Lines[1][27] == '1' else False # scalefc 1

    m42["iedt"]    = []
    m42["tiltcorr"] = []
    m42["nzones"]  = []
    m42["intsteps"]= []
    m42["gmax_BW"]    = []
    m42["Sgmax_BW"]   = []
    m42["Sgmax"]   = []
    m42["RSgmax"]  = []
    m42["DSgmin"]  = []
    m42["OM"]  = []

    if read_frames:
        m42["BlockID"] = []
        m42["FrameID"] = []
        m42["UVW"]   = []
        m42["alpha"] = []
        m42["beta"]  = []
        m42["phi"]   = []   # rotation semiangle or precession angle
        m42["EDphi"]   = [] # optimised frame orientation correction direction
        m42["EDtheta"] = [] # optimised frame orientation correction tilt
        m42["use_flag"]    = []
        m42["thickness"]   = []
        m42["scale"]       = []

    # refinement data block settings
    BlockID = 1
    DSgmin = -1
    for i, line in enumerate(Lines[:end_config_line]):
        if line.startswith('Refblock'):
            BlockID = int( line.split('Block')[1] )
        elif line.startswith('threads'):
            data = line.split()
            tiltcorr = True if data[3]=='1' else False
            iedt = True if data[5]=='1' else False
        elif line.startswith('nzones'):
            data = line.split()
            nzones = int(data[1])
            intsteps = int(data[3])
        elif line.startswith('ormat'):
            OM = np.array( [ l.split() for l in Lines[i+1:i+4] ] ).astype(float)
        elif line.startswith('omega'):
            data = line.split()
            offset = 0
            if 'sca' in line:
                offset = 2
            gmax_BW = float(data[3])
            Sgmax_BW = float(data[5+offset])
            Sgmax = float(data[7+offset])
            RSgmax = float(data[9+offset])
            if 'dsgmin' in line:
                DSgmin = float(data[11+offset])

            m42["iedt"].append(iedt)
            m42["tiltcorr"].append(tiltcorr)
            m42["nzones"].append(nzones)
            m42["intsteps"].append(intsteps)
            m42["gmax_BW"].append(gmax_BW)
            m42["Sgmax_BW"].append(Sgmax_BW)
            m42["Sgmax"].append(Sgmax)
            m42["RSgmax"].append(RSgmax)
            m42["DSgmin"].append(DSgmin)
            m42["OM"].append(OM)

    if not read_frames:
        return m42

    # frame parameters
    before = 0
    BlockID = 1
    for i, line in enumerate(Lines): 
        if line.startswith('# Zone'):
            frameID = int(line[6:].strip().split()[0])

            UVW = [ float(Lines[i+1][k*9:k*9+9]) for k in (0,1,2)]
            alpha = float(Lines[i+1][27:36])
            beta = float(Lines[i+1][36:45])
            phi = float(Lines[i+1][45:54])
            UseFlag = True if Lines[i+1][60] == "T" else False

            scale = float(Lines[i+2][:9])
            thickness = float(Lines[i+2][9:18])
            EDphi = float(Lines[i+3][:9])
            EDtheta = float(Lines[i+3][9:18])

            if frameID < before:
                BlockID += 1

            m42["BlockID"].append( BlockID )
            m42["FrameID"].append( frameID )
            m42["UVW"].append(UVW)
            m42["alpha"].append(alpha)
            m42["beta"].append(beta)
            m42["phi"].append(phi)
            m42["use_flag"].append(UseFlag)
            m42["thickness"].append(thickness)
            m42["scale"].append(scale)

            m42["EDphi"].append(EDphi)
            m42["EDtheta"].append(EDtheta)

            before = frameID
        elif line.startswith('---------------'): # s.u. block
            break
            
    return m42

def m42_import(parent, file=None):
    """ Read M42 file, create object for each block """
    if not file:
        M42file = parent.get_jana_file_path("m42")
    else:
        M42file = file
        
    if M42file:
        with open(M42file, "r") as fh:
            lines = fh.readlines()
    else:
        print("Loading zones from M42 file failed.")
        return dict()
        
    m42 = read_m42(M42file)
    
    BlockIDs = list( set(m42['BlockID']) )
    BlockIDs.sort()
       
    # Get blocks, initialize objects
    
    Blocks = dict()
    for BlockID in BlockIDs:
        Blocks[BlockID] = zoneblock(parent) # init object
        #Blocks[BlockID].ConfigLine = 0
        Blocks[BlockID].BlockID = BlockID
        
    start = 0
    for i, BlockID in enumerate(Blocks.keys()):
        # Block settings
        Block = Blocks[BlockID]
        Block.Origin = M42file
        Block.threads = 0 # ignored
        Block.Geometry = "continuous" if m42['iedt'][i] else "precession"
        Block.nzones = m42['nzones'][i]
        Block.intsteps = m42['intsteps'][i]
        
        Block.OM = tuple( tuple(e) for e in m42['OM'][i] )
        Block.g_max = m42['gmax_BW'][i]
        Block.Sg_max_matrix = m42['Sgmax_BW'][i]
        Block.Sg_max = m42['Sgmax'][i]
        Block.RSg_max = m42['RSgmax'][i]
        
        # Block frames
        end = start + m42['nzones'][i]
        
        Block.ZoneID = m42['FrameID'][start:end]
        Block.Alpha = m42['alpha'][start:end]
        Block.Beta = m42['beta'][start:end]
        Block.Phi = m42['phi'][start:end]
        Block.InRefinement = [ int(e) for e in m42['use_flag'][start:end] ]
        Block.scale = m42['scale'][start:end]
        Block.thickness = m42['thickness'][start:end]
        Block.EDphi = m42['EDphi'][start:end]
        Block.EDtheta = m42['EDtheta'][start:end]
        
        start = end
        
    return Blocks


def cif_pets_import_zones(parent, file=None):
    """ Import zone information from dyn.cif_pets file """
    if not file:
        print("No dyn.cif_pets file provided.")
        return False
    CifPetsFile = file
    fh = open(CifPetsFile, "r")
    
    # Read unit cell and general data
    ParametersList = ("_cell_length_a","_cell_length_b","_cell_length_c",
                      "_cell_angle_alpha","_cell_angle_beta","_cell_angle_gamma",
                      "_cell_volume","_diffrn_radiation_wavelength",
                      "_diffrn_orient_matrix_UB_11","_diffrn_orient_matrix_UB_12","_diffrn_orient_matrix_UB_13",
                      "_diffrn_orient_matrix_UB_21","_diffrn_orient_matrix_UB_22","_diffrn_orient_matrix_UB_23",
                      "_diffrn_orient_matrix_UB_31","_diffrn_orient_matrix_UB_32","_diffrn_orient_matrix_UB_33")
    Measurement = ""
    Parameters = dict()
    Geometry = False
    while True:
        Line = fh.readline()
        Parts = Line.split()
        if Parts and Parts[0] in ParametersList:
            Parameters[Parts[0]] = float(Parts[1])
        elif ":" in Line:
            Measurement += Line
            if Line.startswith("data collection geometry:"):
                Geometry = Line.split(":")[1]
        elif Parts and Parts[0].startswith("loop_"):
            break
    # Read _diffrn_zone_* column labels
    # Current line is "loop_"
    ZoneColumns = []
    while True:
        line = fh.readline()
        if line.startswith("_diffrn_zone_axis_"):
            ZoneColumns.append(line.strip())
        elif len(line.split()) > 4:
            break
    # Read zones
    # Current line is first zone (zone axis id is probably 1)
    Zones = []
    while True:
        Columns = line.split()
        if len(Columns) == len(ZoneColumns):
            Zones.append(Columns)
        else:       # There may not be a blank line after _loop until the end of the block. 
            break   # Breaks automatically at first line with not enough columns, including "loop_" or empty lines
        line = fh.readline()
    fh.close()
    # FINISHED reading zone block and extracting data
    #print(ZoneColumns)
    
    # CREATE ZONE OBJECT
    Block = zoneblock(parent)
    Block.BlockID = 1
    Block.Origin = CifPetsFile
    Block.Diffrn_measurement_details = Measurement
    Block.Wavelength = Parameters["_diffrn_radiation_wavelength"]
    Block.OM = tuple([ tuple([ Parameters["_diffrn_orient_matrix_UB_"+str(row)+str(col)] 
                    for col in (1,2,3) ]) 
                    for row in (1,2,3) ]) # ((UB11,UB12,UB13),(UB21,UB22,UB23),(UB31,UB32,UB33))
    ColumnZoneID = ZoneColumns.index("_diffrn_zone_axis_id")
    ColumnAlpha = ZoneColumns.index("_diffrn_zone_axis_alpha")
    ColumnBeta = ZoneColumns.index("_diffrn_zone_axis_beta")
    ColumnOmega = ZoneColumns.index("_diffrn_zone_axis_omega")
    ColumnPhi = ZoneColumns.index("_diffrn_zone_axis_precession_angle")
    ColumnU = ZoneColumns.index("_diffrn_zone_axis_u")
    ColumnV = ZoneColumns.index("_diffrn_zone_axis_v")
    ColumnW = ZoneColumns.index("_diffrn_zone_axis_w")
    ColumnScale = ZoneColumns.index("_diffrn_zone_axis_scale")
    
    Block.ZoneID = [ int(Line[ColumnZoneID]) for Line in Zones ]
    Block.Alpha = [ float(Line[ColumnAlpha]) for Line in Zones ]
    Block.Beta = [ float(Line[ColumnBeta]) for Line in Zones ]
    Block.Omega = [ float(Line[ColumnOmega]) for Line in Zones ]
    Block.Phi = [ float(Line[ColumnPhi]) for Line in Zones ]
    Block.UVW = [ ( float(Line[ColumnU]),float(Line[ColumnV]),float(Line[ColumnW]) ) for Line in Zones ]
    Block.scale = [ float(Line[ColumnScale]) for Line in Zones ]
    
    if Geometry:
        if "continuous" in Geometry:
            Block.Geometry = "continuous"
        else:
            Block.Geometry = "precession"
    
    return {1: Block}

def ptsopt_import_zones(parent, file=None):
    """ Import original and new zone information from ptsopt file """
    Block = zoneblock(parent)
    Block.BlockID = 1

    if not file:
        print("No .ptsopt file provided.")
        return False
    PtsOptFile = file
    with open(PtsOptFile, "r") as fh:
        Lines = fh.readlines()
    
    ZoneID = 1
    for Line in Lines: # extract data
        if len(Line) < 72: # scale optimization
            break
        if "*" in Line:
            Line = Line.replace("**********", "       NaN")
        FrameFile = Line.split()[0]
        cc = len(FrameFile)
        # Block1, new orientation
        #print(Line)
        AlphaNew = float(Line[cc:cc+10])
        BetaNew = float(Line[cc+10:cc+20])
        OmegaNew = float(Line[cc+20:cc+30])
        Block.ZoneID.append(ZoneID)
        Block.Alpha.append(AlphaNew)
        Block.Beta.append(BetaNew)
        Block.Omega.append(OmegaNew)
        Block.FrameFile.append(FrameFile)
        
        # Block1, original orientation
        Alpha = float(Line[cc+73:cc+83])
        Beta = float(Line[cc+83:cc+93])
        Omega = float(Line[cc+93:cc+103])
        Block.Alpha0.append(Alpha)
        Block.Beta0.append(Beta)
        Block.Omega0.append(Omega)
        
        Block.AlphaCorrection.append(AlphaNew-Alpha)
        Block.BetaCorrection.append(BetaNew-Beta)
        Block.OmegaCorrection.append(OmegaNew-Omega)
        
        ZoneID += 1
        #if ZoneID > 100:
        #    break
    return {1: Block}

def m90_wavelength(parent, blockid=1):
    """ Return wavelength of blockid """    
    m90file = parent.get_jana_file_path("m90")
    if not m90file:
        return None
    fh = open(m90file, "r")
    Wavelength = None
    Block = 0
    while True:
        line = fh.readline()
        if line.startswith("end") or line.startswith("Data"):
            break
        elif line.startswith("datblock"):
            Block = int(line.split("Block")[-1])
        elif line.startswith("lambda") and Block == blockid:
            Wavelength = float(line.split()[1])
    fh.close()
    return Wavelength

def m95_wavelength(parent, blockid=1):
    """ Return wavelength of blockid """
    m95file = parent.get_jana_file_path("m95")
    #Wavelength = dict()
    #Source = dict()
    #SourceDate = dict()
    #SourceTime = dict()
    if not m95file:
        return None
    fh = open(m95file, "r")
    Wavelength = None
    Block = 0
    while True:
        line = fh.readline()
        if line.startswith("end") or line.startswith("Data"):
            break
        elif line.startswith("refblock"):
            Block = int(line.split("Block")[-1])
        elif line.startswith("lambda") and Block == blockid:
            Wavelength = float(line.split()[1])
            #Wavelength[Block] = float(line.split()[1])
        """
        elif line.startswith("sourcefile"):
            self.Source[Block] = line.split()[1]
        elif line.startswith("filedate"):
            tmp, Date, tmp, Time = line.split()
            self.SourceDate[Block] = Date
            self.SourceTime[Block] = Time
        """
    fh.close()
    return Wavelength

# T E S T
#test = m42_import(None, file="D:\\OneDrive\\ED_Data\\NEW_DYNGO\\CAP\\n_1-freedom.m42")
#print(len(test[1].Alpha))
    
# T E S T
#test = cif_pets_import_zones(None, file="D:\\OneDrive\\ED_Data\\2019-09_Stockholm\\Mordenite\\s3m6_cont_FO\\s3m6_dyn.cif_pets")
#print(len(test[999].Alpha))
#print(test.Alpha[0], test.Beta[0], test.Phi[0])

# T E S T
#test = ptsopt_import_zones(None, file='D:\\OneDrive\\SCIENCE\\2019-06_RED_IEDT_PEDT\\H_Hemimorphite\\200220-7-000.ptsopt')
#test = ptsopt_import_zones(None, file='D:\\OneDrive\\SCIENCE\\2020-03_ConTilt\\Quartz\\200302-01\\200302-01-000.ptsopt')
#test[1].calc_steps()
#test[1].smooth_steps()

"""
M42 FORMAT:
    "commands"
    1 line of global ED settings
    [Refblock BlockX]
    7 lines/block local block settings
    "end"
    ***********
    [Refblock BlockX]
    4 lines/zone
"""

"""
def list_zonesBAK(self, event=None):
        self.log("\n***** PRINT FRAME LIST from M42 *****\n")
        #>>>>>>> Block Frame# Ref_Flag Scale Thickness phi alpha beta EDphi EDtheta 
        form = "{:>5d} {:>4d} {:>3d} {:8.2f} {:9.3f} {:8.4f} {:8.4f} {:8.4f} {:10.4f} {:10.4f}"
        self.log("Block Zone Ref    Scale Thickness      Phi    Alpha     Beta      EDphi    EDtheta")
        for j, ZoneID in enumerate(self.ZoneID):
            self.log(form.format(ZoneID, self.InRefinement[j], 
                                      self.scale[j], self.thickness[j], 
                                      self.Phi[j], self.Alpha[j], self.Beta[j],
                                      self.EDphi[j], self.EDtheta[j]))
"""            

"""
def m42_import(parent, file=None):
    #Read M42 file, create object for each block
    if not file:
        M42file = parent.get_jana_file_path("m42")
    else:
        M42file = file
        
    if M42file:
        with open(M42file, "r") as fh:
            lines = fh.readlines()
    else:
        print("Loading zones from M42 file failed.")
        return dict()
    """
# Get global m42 settings
#calcdyn = int(lines[1][8])
#calcfc = int(lines[1][27])
#usetwver = int(lines[1][38])
"""
       
    # Get blocks, initialize objects
    i = 2
    Blocks = dict()
    while(lines[i].startswith("Refblock")):
        BlockID = int(lines[i][14:])
        Blocks[BlockID] = zoneblock(parent) # init object
        Blocks[BlockID].ConfigLine = i
        Blocks[BlockID].BlockID = BlockID
        i += 8
    if len(Blocks) == 0:
        Blocks[1] = zoneblock(parent) # init object
        Blocks[1].ConfigLine = 1
        Blocks[1].BlockID = 1
        
    # Get block settings
    for BlockID in Blocks.keys():
        Block = Blocks[BlockID]
        Block.Origin = M42file
        zero = Block.ConfigLine + 1
        
        line = lines[zero] # threads tiltcorr iedt
        data = line.split()
        threads = 
        tmp, threads, tmp, tmp, tmp, iedt =
        Block.threads = int(threads)
        Block.Geometry = "continuous" if iedt == "1" else "precession"
        
        line = lines[zero+1] # nzones intsteps
        tmp, nzones, tmp, intsteps = line.split()
        Block.nzones = int(nzones)
        Block.intsteps = int(intsteps)
        
        OM = []
        for j in range(3):
            OMline = lines[zero+3+j].split() # OM a11 a12 a13
            OMline = tuple([ float(a) for a in OMline])
            OM.append(OMline)
        Block.OM = tuple(OM)
        
        line = lines[zero+6].split() # omega gmax sgmax sgmaxr csgmaxr
        Block.g_max = float(line[3])
        Block.Sg_max_matrix = float(line[5])
        Block.Sg_max = float(line[7])
        Block.RSg_max = float(line[9])
        
    
    
        
    # Get zones (ZoneID and R factor is currently not extracted. ZoneID thus is defined by the position in the lists.)
    nBlocks = len(Blocks)
    if nBlocks > 1:
        offset = 1
    else:
        offset = 0
    starLine = 2 + nBlocks*7 + offset*nBlocks + 1 # first 2 lines, 7 per block, one more for "Refblock BlockN", 1 for "end"        
    
    # new version skips RefBlock line in list of frames
    if 'Zone' in lines[starLine+1]:
        refblockline = 0
    elif lines[starLine+1].startswith('Refblock'):
        refblockline = 1
    
    zero = starLine + refblockline + offset # first "# Zone" line of block 1
    
    for BlockID in Blocks.keys():
        Block = Blocks[BlockID]
        for j in range(Block.nzones):
            #  0.640950-1.000000 0.755480-58.99800-1.297000 1.500000      T   1
            line = lines[zero].split()
            Block.ZoneID.append(int(line[2]))
            
            line = lines[zero+1] # u v w alpha beta phi ... refine flag, equal_thickness_flag
            Block.Alpha.append(float(line[27:36]))
            Block.Beta.append(float(line[36:45]))
            Block.Phi.append(float(line[45:54]))
            refine = 1 if line[60] == "T" else 0
            Block.InRefinement.append(refine)
            
            line = lines[zero+2]
            Block.scale.append(float(line[:9]))
            Block.thickness.append(float(line[9:18]))
            
            line = lines[zero+3]
            Block.EDphi.append(float(line[:9]))
            Block.EDtheta.append(float(line[9:18]))
            zero += 4
        #zero += 1 # 1 for line "Refblock BlockN"
        zero += refblockline
    return Blocks
"""
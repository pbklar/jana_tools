# -*- coding: utf-8 -*-

from dynrockmath import *

from math import atan, asin, acos

PI = 3.141592653589793238462643383279502889

# print(standard_uncertainty([12.02, 11.96, 11.99, 12.00, 12.02]))

OM1 = (
(-0.01023,   0.03290,  -0.11422),
(-0.03451,   0.02909,   0.08760),
( 0.04181,   0.03060,   0.04428))

OM3 = (
(-0.009486,  0.032472, -0.115454),
(-0.033284,  0.030466,  0.087132),
( 0.042981,  0.029644,  0.042056))

print(direction_angles(OM1))
print(direction_angles(OM3))


# MORDENITE
# D:\OneDrive\ED_Data\2019-09_Stockholm\Mordenite\s3m6\OO

print("S E T T I N G S :")
lamda = 0.0251
k=calc_wavevector(0.0251)
print("lambda = ", lamda)
print("Data set: D:\OneDrive\ED_Data\2019-09_Stockholm\Mordenite\s3m6\OO")

# zone2
alpha0 = -42.1
beta0 = -0.13
omega0 = -129.38

OM =  (
 ( 0.047987,  0.021084, -0.010646),
 ( 0.007938, -0.024764, -0.109255),
 (-0.021828,  0.036030, -0.068246))

print("ZoneID 2:", "alpha beta omega", alpha0, beta0, omega0)
print("Orientation matrix:", OM)
print("Check reflection: 2 0 2")
print("PETS 2.0 reference: Sg = 0.00132\n")
# 2 0 2 on #2 with Sg = 0.00132

hkl = (2,0,2)
xyz = xyz_from_hkl(OM, hkl)
r1 = rotationmatrix(alpha0,0,0)
r2 = rotationmatrix(0,beta0,0)
r3 = rotationmatrix(0,0,omega0)

""""""
###############################################################################
print("B e t a,  A l p h a,  O m e g a :")
RotX = xyz
RotX = xyz_rotate(RotX, r2)
RotX = xyz_rotate(RotX, r1)
Sg_BA = calc_sg(k,RotX)
RotX = xyz_rotate(RotX, r3)
Sg_BAO = calc_sg(k,RotX)
print("1) Rotate about beta, then alpha:")
print(round(Sg_BA,5))
print("2) Rotate about beta, then alpha, then omega:")
print(round(Sg_BAO,5))

RotX = xyz_rotate(xyz_rotate(xyz_rotate(xyz, r2), r1), r3)
Sg_BAO = calc_sg(k,RotX)
print(round(Sg_BAO,5), "( one line xyz rotate ))")

# BETA ALPHA OMEGA, via matrixproduct
m1 = matrixproduct(r1, r2) # beta alpha
m2 = matrixproduct(r3, m1) # omega m1
m3 = matrixproduct(m2, OM)
Sg_MatBAO = calc_sg(k, xyz_from_hkl(m3, hkl) )
print(round(Sg_MatBAO,5), "( matrix product B A O )" )

RotOM = matrixproduct( matrixproduct(matrixproduct(r3, r1),r2), OM)
Sg_MatBAO = calc_sg(k, xyz_from_hkl(RotOM, hkl))
print(round(Sg_MatBAO,5), "( one line (Rot.OM).hkl )" )
print()


###############################################################################
print("B e t a,  A l p h a,  ED p h i,  ED t h e t a:")
print("(omega' is independent of omega in PETS)")
alpha1 = -42.173095
beta1 = -0.485003
omega1 = -0.238172

EDphi = 164.3629
EDtheta = 0.273211

print("New Alpha', Beta', Omega': ", alpha1, beta1, omega1, " (reference from JANA)")
print("Old Alpha, Beta: ", alpha0, beta0)
print("EDphi, EDtheta: ", EDphi, EDtheta, "\n")

n1 = rotationmatrix(alpha1,0,0)
n2 = rotationmatrix(0,beta1,0)
n3 = rotationmatrix(0,0,omega1)

p1 = rotationmatrix(0, 0, -EDphi)
p2 = rotationmatrix(0, EDtheta, 0) #Rotate2
p3 = rotationmatrix(0, 0, EDphi)

RotXn = xyz
RotXn = xyz_rotate(RotXn, n2)
RotXn = xyz_rotate(RotXn, n1)
RotXn = xyz_rotate(RotXn, n3) # this is OMEGA
Sg_BAOn = calc_sg(k, RotXn)

RotOMprimen = matrixproduct( matrixproduct(matrixproduct(n3, n1),n2), OM)
Sg_MatBAOn = calc_sg(k, xyz_from_hkl(RotOMprimen, hkl))

print("3) New Sg from Beta', Alpha', Omega'")
print(round(Sg_MatBAOn,5), round(Sg_BAOn,5))

RotOMn = matrixproduct( matrixproduct(matrixproduct(matrixproduct(p3,p2),p1), matrixproduct(r1, r2)), OM)
Sg_MatPTPBA = calc_sg(k, xyz_from_hkl(RotOMn, hkl))
print("4) New Sg from -EDphi, EDtheta, EDphi, beta, alpha")
print(round(Sg_MatPTPBA,5))
#print(RotOMprimen)
#print(RotOMn)
print()

###############################################################################
print("A l p h a,  B e t a,  O m e g a   from   ED p h i,  ED t h e t a:")

RotOMn = matrixproduct(matrixproduct(matrixproduct(p3,p2),p1), matrixproduct(r1, r2))

r32 = RotOMn[2][1]
r33 = RotOMn[2][2]
r31 = RotOMn[2][0]
r21 = RotOMn[1][0]
r22 = RotOMn[1][1]
r23 = RotOMn[1][2]
r11 = RotOMn[0][0]
r12 = RotOMn[0][1]
r13 = RotOMn[0][2]

thetaX = acos(r23/r33)*180/PI
thetaY = asin(-r31/sqrt(r32**2+r33**2))*180/PI
thetaZ = asin(r12/r11)*180/PI

print(round(thetaX,3))
print(round(thetaY,3))
print(round(thetaZ,3))

EDphi=60
EDtheta=45
Alpha=15
Beta=20
Ralpha = rotationmatrix(alpha=Alpha)
Rbeta = rotationmatrix(beta=Beta)
GoniometerRotation = matrixproduct(Ralpha, Rbeta)
Rphi = rotationmatrix(gamma=EDphi)
Rtheta = rotationmatrix(beta=EDtheta)
R_phi = rotationmatrix(gamma=-EDphi) # negative phi
GoniometerCorrection = matrixproduct(matrixproduct(Rphi,Rtheta),R_phi) # (Rphi.Rtheta).R_phi
RotationMatrix =  matrixproduct(GoniometerCorrection, GoniometerRotation)  # [(Rphi.Rtheta).R_phi].(Ralpha.Rbeta)
print(GoniometerCorrection)
print()
print(RotationMatrix)
"""
\theta_x = arctan(r_{3,2}/r_{3,3})
\theta_y = -arcsin(r_{3,1})
\theta_z = arctan(r_{2,1}/r_{1,1})
#RotXp = row_vector(matrixproduct( matrixproduct(matrixproduct(matrixproduct(p3,p2),p1),m1), matrixproduct(OM, column_vector(hkl)) ) )
print(RotXn, "alpha' beta' from Jana")
print(RotXp, "EDphi EDtheta from Jana")
print("{:8.6f}".format(sum([ abs(RotXp[i] - RotXn[i]) for i in range(3) ])), " absolute delta XYZ")
#print("{:8.6f}".format(sum([ abs(RotX[i] - RotXn[i]) for i in range(3) ])), " absolute delta XYZ")
"""